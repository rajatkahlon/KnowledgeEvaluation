import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;


public class AdminQuestions extends JFrame implements ActionListener{

    JLabel back = new JLabel("");
	JLabel frameInfo = new JLabel("");
	
	JRadioButton Java = new JRadioButton("JAVA");
	JRadioButton CPlus = new JRadioButton("C++");
	JRadioButton C = new JRadioButton("C");
	
	JPanel QuestionInfo = new JPanel();
	JPanel JavaPanel = new JPanel();
	JPanel CppPanel = new JPanel();
	JPanel CPanel = new JPanel();
	
	JTextPane admin = new JTextPane();
	
	/******JAVA********/
	JLabel quesNo1 = new JLabel("Ques. No.");
	JTextField NoTxt1 = new JTextField();
	JButton submit1 = new JButton("SUBMIT");
	JLabel question1 = new JLabel("Question:");
	JTextArea quesArr1 = new JTextArea();
	JScrollPane quesScr1 = new JScrollPane(quesArr1, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JLabel options1 = new JLabel("Options:");
	JTextField optFld11 = new JTextField();
	JScrollPane optscr1 = new JScrollPane(optFld11, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField optFld21 = new JTextField();
	JScrollPane optscr21= new JScrollPane(optFld21, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField optFld31 = new JTextField();
	JScrollPane optscr31 = new JScrollPane(optFld31, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField optFld41 = new JTextField();
	JScrollPane optscr41 = new JScrollPane(optFld41, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JLabel answer1 = new JLabel("Answer:");
	JTextField AnsTxt1 = new JTextField();
	JButton next1 = new JButton("NEXT");
	JButton previous1 = new JButton("PREVIOUS");
	JButton Back1 = new JButton("BACK");
	JButton exit1 = new JButton("EXIT");
	
	String QuestionNo1;
	
	/******C++*******/
	JLabel quesNo2 = new JLabel("Ques. No.");
	JTextField NoTxt2 = new JTextField();
	JButton submit2 = new JButton("SUBMIT");
	JLabel question2 = new JLabel("Question:");
	JTextArea quesArr2 = new JTextArea();
	JScrollPane quesScr2 = new JScrollPane(quesArr2, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JLabel options2 = new JLabel("Options:");
	JTextField optFld12 = new JTextField();
	JScrollPane optscr12 = new JScrollPane(optFld12, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField optFld22 = new JTextField();
	JScrollPane optscr22 = new JScrollPane(optFld22, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField optFld32 = new JTextField();
	JScrollPane optscr32 = new JScrollPane(optFld32, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField optFld42 = new JTextField();
	JScrollPane optscr42 = new JScrollPane(optFld42, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JLabel answer2= new JLabel("Answer:");
	JTextField AnsTxt2 = new JTextField();
	JButton next2 = new JButton("NEXT");
	JButton previous2 = new JButton("PREVIOUS");
	JButton Back2 = new JButton("BACK");
	JButton exit2 = new JButton("EXIT");
	
	String QuestionNo2;
	
	/******C*******/
	JLabel quesNo3 = new JLabel("Ques. No.");
	JTextField NoTxt3 = new JTextField();
	JButton submit3 = new JButton("SUBMIT");
	JLabel question3 = new JLabel("Question:");
	JTextArea quesArr3 = new JTextArea();
	JScrollPane quesScr3 = new JScrollPane(quesArr3, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JLabel options3 = new JLabel("Options:");
	JTextField optFld13 = new JTextField();
	JScrollPane optscr13 = new JScrollPane(optFld13, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField optFld23 = new JTextField();
	JScrollPane optscr23 = new JScrollPane(optFld23, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField optFld33 = new JTextField();
	JScrollPane optscr33 = new JScrollPane(optFld33, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField optFld43 = new JTextField();
	JScrollPane optscr43 = new JScrollPane(optFld43, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JLabel answer3 = new JLabel("Answer:");
	JTextField AnsTxt3 = new JTextField();
	JButton next3 = new JButton("NEXT");
	JButton previous3 = new JButton("PREVIOUS");
	JButton Back3 = new JButton("BACK");
	JButton exit3 = new JButton("EXIT");
	
	String QuestionNo3;
	/*************/
	
	/******CONSTRUCTOR*******/
	Connection con;
	public AdminQuestions()
	{
		setBounds(300, 30, 600, 700);
		setTitle("Questions");
		setLayout(null);
		/////
		back.setBounds(0, 0, 600, 700);
		ImageIcon bac = new ImageIcon("imgs/backgroundLong.jpg");
		back.setIcon(bac);
		add(back);
		//////////////
		/************/
		admin.setBounds(50, 50, 400, 400);
		admin.setBackground(new Color(230, 150, 200));
		admin.setText("In this Frame You have a Right to see the questions of all the fields that are set by our faculty." +
				"\n"+"By clicking on the respective fields you are able to see the questions assigned to students of that" +
						" particular field.");
		admin.setFont(new Font("times new roman",0,30));
		admin.setForeground(Color.RED);
		admin.setEditable(false);
		JButton Back = new JButton("BACK");
		Back.setBounds(150, 360, 100, 30);
		Back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new adminRights();
				dispose();
				
			}
		});
		admin.add(Back);
		QuestionInfo.add(admin);
		/****************/
		/////////////////
		frameInfo.setBounds(50, 15, 500, 40);
		//frameInfo.setOpaque(true);
		frameInfo.setForeground(Color.BLUE);
		frameInfo.setFont(new Font("algerian", Font.ITALIC, 30));
		back.add(frameInfo);
		frameInfo.setText("INSTRUCTIONS:");
		
		ButtonGroup bg = new ButtonGroup();
		Java.setBounds(100, 70, 100, 20);
		bg.add(Java);
		Java.addActionListener(this);
		back.add(Java);
		CPlus.setBounds(250, 70, 100, 20);
		bg.add(CPlus);
		CPlus.addActionListener(this);
		back.add(CPlus);
		C.setBounds(400, 70, 100, 20);
		bg.add(C);
		C.addActionListener(this);
		back.add(C);
		/*************/
		QuestionInfo.setBounds(50,120,500,500);
		QuestionInfo.setBackground(new Color(230, 150, 200));
		QuestionInfo.setLayout(null);
		back.add(QuestionInfo);
		QuestionInfo.setVisible(true);
		/*************/
		
		/******JAVA*******/
		JavaPanel.setBounds(50, 120, 500, 500);
		JavaPanel.setBackground(new Color(230, 150, 200));
		JavaPanel.setLayout(null);
		back.add(JavaPanel);
		//////
		
		quesNo1.setBounds(20, 20, 80, 30);
		JavaPanel.add(quesNo1);
		NoTxt1.setBounds(110, 20, 100, 30);
		JavaPanel.add(NoTxt1);
		submit1.setBounds(240, 20, 100, 30);
		/****SUBMIT 1 START********/
		submit1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				QuestionNo1 = NoTxt1.getText();
				con = CreateConnection.connect();
		        if(!QuestionNo1.equals("")){
		       try {
				PreparedStatement  pstmt1 = con.prepareStatement("Select * from javaques where id = ? ");
				pstmt1.setString(1,QuestionNo1);
				
				
				ResultSet rs1 = pstmt1.executeQuery();
				if(rs1.next())
				{
				quesArr1.setText(rs1.getString(1));
				
				optFld11.setText(rs1.getString(2));
				optFld21.setText(rs1.getString(3));
				optFld31.setText(rs1.getString(4));
				optFld41.setText(rs1.getString(5));
				AnsTxt1.setText(rs1.getString(6));
				
				
				}
				else
				{
					JOptionPane.showMessageDialog(null, "No Record Exist for "+QuestionNo1+ " Question No.");
					NoTxt1.setText("");
				}
				pstmt1.close();
				rs1.close();
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
		        }
		        else
		        {
		        	JOptionPane.showMessageDialog(null, "Please Enter a Question No.");
		        }
			
				
			}
		});
		/****SUBMIT 1 FINISH********/
		JavaPanel.add(submit1);
		question1.setBounds(20, 60,80, 30);
		JavaPanel.add(question1);
		quesScr1.setBounds(110, 60, 300, 100);
		
		quesArr1.setEditable(false);
		quesArr1.setBackground(new Color(225, 230, 230));
		quesArr1.setBorder(BorderFactory.createEtchedBorder());
		JavaPanel.add(quesScr1);
		options1.setBounds(20, 170, 80, 30);
		JavaPanel.add(options1);
		optscr1.setBounds(110, 170, 200, 40);
		optFld11.setEditable(false);
		JavaPanel.add(optscr1);
		optscr21.setBounds(110, 215,200, 40);
		optFld21.setEditable(false);
		JavaPanel.add(optscr21);
		optscr31.setBounds(110, 260, 200, 40);
		optFld31.setEditable(false);
		JavaPanel.add(optscr31);
		optscr41.setBounds(110, 305, 200, 40);
		optFld41.setEditable(false);
		JavaPanel.add(optscr41);
		answer1.setBounds(20, 355, 80, 30);
		JavaPanel.add(answer1);
		AnsTxt1.setBounds(110, 355, 100, 30);
		AnsTxt1.setEditable(false);
		JavaPanel.add(AnsTxt1);
		next1.setBounds(200, 400, 100, 30);
		 /*****NEXT 1*****/
        next1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String Question1=NoTxt1.getText();
			    int Increement;
				Increement = Integer.valueOf(Question1)+1;
				
				while(Increement<=25)
				{
				NoTxt1.setText(String.valueOf(Increement));
				
				
				con = CreateConnection.connect();
		       
		       try {
				PreparedStatement  pstmt1 = con.prepareStatement("Select * from javaques where id =?  ");
				pstmt1.setInt(1,Increement);
				
				
				ResultSet rs1 = pstmt1.executeQuery();
				if(rs1.next())
				{
				quesArr1.setText(rs1.getString(1));
				
				optFld11.setText(rs1.getString(2));
				optFld21.setText(rs1.getString(3));
				optFld31.setText(rs1.getString(4));
				optFld41.setText(rs1.getString(5));
				AnsTxt1.setText(rs1.getString(6));
				
				
				}
				
				pstmt1.close();
				rs1.close();
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
		        
		       break;
				}
				
			}
		});
        /*****NEXT 1*****/
		JavaPanel.add(next1);
		previous1.setBounds(50, 400, 100, 30);
		 /*****Previous 1*****/
        previous1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String Question1=NoTxt1.getText();
			    int decreement;
				decreement = Integer.valueOf(Question1)-1;
				
				while(decreement>=1)
				{
				NoTxt1.setText(String.valueOf(decreement));
				con = CreateConnection.connect();
			       
			       try {
					PreparedStatement  pstmt1 = con.prepareStatement("Select * from javaques where id =?  ");
					pstmt1.setInt(1,decreement);
					
					
					ResultSet rs1 = pstmt1.executeQuery();
					if(rs1.next())
					{
					quesArr1.setText(rs1.getString(1));
					
					optFld11.setText(rs1.getString(2));
					optFld21.setText(rs1.getString(3));
					optFld31.setText(rs1.getString(4));
					optFld41.setText(rs1.getString(5));
					AnsTxt1.setText(rs1.getString(6));
					
					
					}
					
					pstmt1.close();
					rs1.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			        
			    
				break;
				}
				
				
			}
		});
        /*****Previous 1*****/
		JavaPanel.add(previous1);
		Back1.setBounds(350, 400, 100, 30);
		/*****Back 1******/
		Back1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new adminRights();
				dispose();
				
			}
		});
		/*****BACK 1*****/
		JavaPanel.add(Back1);
		/****EXIT 1******/
		 exit1.setBounds(200, 440, 100, 30);
		 exit1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			dispose();
				
			}
		});
			
		JavaPanel.add(exit1);
		/****Exit 1******/
		//////
		JavaPanel.setVisible(false);
		/*************/
		
		/******C++*******/
		CppPanel.setBounds(50, 120, 500, 500);
		CppPanel.setBackground(new Color(230, 150, 200));
		CppPanel.setLayout(null);
		quesNo2.setBounds(20, 20, 80, 30);
		CppPanel.add(quesNo2);
		NoTxt2.setBounds(110, 20, 100, 30);
		CppPanel.add(NoTxt2);
		submit2.setBounds(240, 20, 100, 30);
		/****SUBMIT 2 START********/
		submit2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				QuestionNo2 = NoTxt2.getText();
				con = CreateConnection.connect();
		        if(!QuestionNo2.equals("")){
		       try {
				PreparedStatement  pstmt1 = con.prepareStatement("Select * from cppques where id = ? ");
				pstmt1.setString(1,QuestionNo2);
				
				
				ResultSet rs1 = pstmt1.executeQuery();
				if(rs1.next())
				{
				quesArr2.setText(rs1.getString(1));
				
				optFld12.setText(rs1.getString(2));
				optFld22.setText(rs1.getString(3));
				optFld32.setText(rs1.getString(4));
				optFld42.setText(rs1.getString(5));
				AnsTxt2.setText(rs1.getString(6));
				
				
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Please enter the Question No between 0-25..");
					NoTxt2.setText("");
				}
				pstmt1.close();
				rs1.close();
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
		        }
		        else
		        {
		        	JOptionPane.showMessageDialog(null, "Please Enter a Question No.");
		        }
			
				
			}
		});
		/****SUBMIT 2 FINISH********/
		CppPanel.add(submit2);
		question2.setBounds(20, 60,80, 30);
		CppPanel.add(question2);
		quesScr2.setBounds(110, 60, 300, 100);
		quesArr2.setEditable(false);
		quesArr2.setBackground(new Color(225, 230, 230));
		quesArr2.setBorder(BorderFactory.createEtchedBorder());
		CppPanel.add(quesScr2);
		options2.setBounds(20, 170, 80, 30);
		CppPanel.add(options2);
		optscr12.setBounds(110, 170, 200, 40);
		optFld12.setEditable(false);
		CppPanel.add(optscr12);
		optscr22.setBounds(110, 215,200, 40);
		optFld22.setEditable(false);
		CppPanel.add(optscr22);
		optscr32.setBounds(110, 260, 200, 40);
		optFld32.setEditable(false);
		CppPanel.add(optscr32);
		optscr42.setBounds(110, 305, 200, 40);
		optFld42.setEditable(false);
		CppPanel.add(optscr42);
		answer2.setBounds(20, 355, 80, 30);
		CppPanel.add(answer2);
		AnsTxt2.setBounds(110, 355, 100, 30);
		AnsTxt2.setEditable(false);
		CppPanel.add(AnsTxt2);
        next2.setBounds(200, 400, 100, 30);
        /*****NEXT 2*****/
        next2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String Question2=NoTxt2.getText();
			    int Increement;
				Increement = Integer.valueOf(Question2)+1;
				
				while(Increement<=25)
				{
				NoTxt2.setText(String.valueOf(Increement));
				con = CreateConnection.connect();
			       
			       try {
					PreparedStatement  pstmt1 = con.prepareStatement("Select * from cppques where id =?  ");
					pstmt1.setInt(1,Increement);
					
					
					ResultSet rs1 = pstmt1.executeQuery();
					if(rs1.next())
					{
					quesArr2.setText(rs1.getString(1));
					
					optFld12.setText(rs1.getString(2));
					optFld22.setText(rs1.getString(3));
					optFld32.setText(rs1.getString(4));
					optFld42.setText(rs1.getString(5));
					AnsTxt2.setText(rs1.getString(6));
					
					
					}
					
					pstmt1.close();
					rs1.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			        
			    
				break;
				
				}
				
			}
		});
        /*****NEXT 2*****/
        CppPanel.add(next2);
		previous2.setBounds(50, 400, 100, 30);
		 /*****Previous 2*****/
        previous2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String Question2=NoTxt2.getText();
			    int decreement;
				decreement = Integer.valueOf(Question2)-1;
				
				while(decreement>=1)
				{
				NoTxt2.setText(String.valueOf(decreement));
				con = CreateConnection.connect();
			       
			       try {
					PreparedStatement  pstmt1 = con.prepareStatement("Select * from cppques where id =?  ");
					pstmt1.setInt(1,decreement);
					
					
					ResultSet rs1 = pstmt1.executeQuery();
					if(rs1.next())
					{
					quesArr2.setText(rs1.getString(1));
				
					optFld12.setText(rs1.getString(2));
					optFld22.setText(rs1.getString(3));
					optFld32.setText(rs1.getString(4));
					optFld42.setText(rs1.getString(5));
					AnsTxt2.setText(rs1.getString(6));
					
					
					}
					
					pstmt1.close();
					rs1.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			        
			    
				break;
				}
				
				
			}
		});
        /*****Previous 2*****/
		CppPanel.add(previous2);
		Back2.setBounds(350, 400, 100, 30);
		/*****Back 2******/
		Back2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new adminRights();
				dispose();
				
			}
		});
		/*****BACK 2*****/
		CppPanel.add(Back2);
		/****EXIT 2******/
		 exit2.setBounds(200, 440, 100, 30);
		 exit2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			dispose();
				
			}
		});
			
		CppPanel.add(exit2);
		/****Exit 2******/
		///////
		back.add(CppPanel);
		CppPanel.setVisible(false);
		/*************/
		
		/******C*******/
		CPanel.setBounds(50, 120, 500, 500);
	    CPanel.setBackground(new Color(230, 150, 200));
		CPanel.setLayout(null);
		quesNo3.setBounds(20, 20, 80, 30);
		CPanel.add(quesNo3);
		NoTxt3.setBounds(110, 20, 100, 30);
		CPanel.add(NoTxt3);
		submit3.setBounds(240, 20, 100, 30);
		/****SUBMIT 3 START********/
		submit3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				QuestionNo3 = NoTxt3.getText();
				con = CreateConnection.connect();
		        if(!QuestionNo3.equals("")){
		       try {
				PreparedStatement  pstmt1 = con.prepareStatement("Select * from cques where id = ? ");
				pstmt1.setString(1,QuestionNo3);
				
				
				ResultSet rs1 = pstmt1.executeQuery();
				if(rs1.next())
				{
				quesArr3.setText(rs1.getString(1));
				
				optFld13.setText(rs1.getString(2));
				optFld23.setText(rs1.getString(3));
				optFld33.setText(rs1.getString(4));
				optFld43.setText(rs1.getString(5));
				AnsTxt3.setText(rs1.getString(6));
				
				
				}
				else
				{
					JOptionPane.showMessageDialog(null, "No Record Exist for "+QuestionNo3+ " Question No.");
					NoTxt3.setText("");
				}
				pstmt1.close();
				rs1.close();
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
		        }
		        else
		        {
		        	JOptionPane.showMessageDialog(null, "Please Enter a Question No.");
		        }
			
				
			}
		});
		/****SUBMIT 3 FINISH********/
		CPanel.add(submit3);
		question3.setBounds(20, 60,80, 30);
		CPanel.add(question3);
		quesScr3.setBounds(110, 60, 300, 100);
		quesArr3.setEditable(false);
		quesArr3.setBackground(new Color(225, 230, 230));
		quesArr3.setBorder(BorderFactory.createEtchedBorder());
		CPanel.add(quesScr3);
		options3.setBounds(20, 170, 80, 30);
		CPanel.add(options3);
		optscr13.setBounds(110, 170, 200, 40);
		optFld13.setEditable(false);
		CPanel.add(optscr13);
		optscr23.setBounds(110, 215,200, 40);
		optFld23.setEditable(false);
		CPanel.add(optscr23);
		optscr33.setBounds(110, 260, 200, 40);
		optFld33.setEditable(false);
		CPanel.add(optscr33);
		optscr43.setBounds(110, 305, 200, 40);
		optFld43.setEditable(false);
		CPanel.add(optscr43);
		answer3.setBounds(20, 355, 80, 30);
		CPanel.add(answer3);
		AnsTxt3.setBounds(110, 355, 100, 30);
		AnsTxt3.setEditable(false);
		CPanel.add(AnsTxt3);
        next3.setBounds(200, 400, 100, 30);
        /*****NEXT 3*****/
        next3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String Question3=NoTxt3.getText();
			    int Increement;
				Increement = Integer.valueOf(Question3)+1;
				
				while(Increement<=25)
				{
				NoTxt3.setText(String.valueOf(Increement));
				con = CreateConnection.connect();
			       
			       try {
					PreparedStatement  pstmt1 = con.prepareStatement("Select * from cques where id =?  ");
					pstmt1.setInt(1,Increement);
					
					
					ResultSet rs1 = pstmt1.executeQuery();
					if(rs1.next())
					{
					quesArr3.setText(rs1.getString(1));
					
					optFld13.setText(rs1.getString(2));
					optFld23.setText(rs1.getString(3));
					optFld33.setText(rs1.getString(4));
					optFld43.setText(rs1.getString(5));
					AnsTxt3.setText(rs1.getString(6));
					
					
					}
					
					pstmt1.close();
					rs1.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			        
			    
				break;
				
				}
				
			}
		});
        /*****NEXT 3*****/
        ///////////////
        CPanel.add(next3);
		previous3.setBounds(50, 400, 100, 30);
		 /*****Previous 3*****/
        previous3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String Question3=NoTxt3.getText();
			    int decreement;
				decreement = Integer.valueOf(Question3)-1;
				
				while(decreement>=1)
				{
				NoTxt3.setText(String.valueOf(decreement));
				con = CreateConnection.connect();
			       
			       try {
					PreparedStatement  pstmt1 = con.prepareStatement("Select * from cques where id =?  ");
					pstmt1.setInt(1,decreement);
					
					
					ResultSet rs1 = pstmt1.executeQuery();
					if(rs1.next())
					{
					quesArr3.setText(rs1.getString(1));
					
					optFld13.setText(rs1.getString(2));
					optFld23.setText(rs1.getString(3));
					optFld33.setText(rs1.getString(4));
					optFld43.setText(rs1.getString(5));
					AnsTxt3.setText(rs1.getString(6));
					
					
					}
					
					pstmt1.close();
					rs1.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			        
			    
				break;
				}
				
				
			}
		});
        /*****Previous 3*****/
		CPanel.add(previous3);
		Back3.setBounds(350, 400, 100, 30);
		/*****Back 3******/
		Back3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new adminRights();
				dispose();
				
			}
		});
		/*****BACK 3*****/
		/////////////////
		CPanel.add(Back3);
		///////
		back.add(CPanel);
		/****EXIT 3******/
		 exit3.setBounds(200, 440, 100, 30);
		 exit3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			dispose();
				
			}
		});
			
		CPanel.add(exit3);
		/****Exit 3******/
		CPanel.setVisible(false);
		/*************/
		/////
	    /////
			int width=0;int height =0;
			if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
			{	width=640;height=460;}
			else
			{
			width=720;height=540;	
			}
			Dimension dim= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
			//setLocation((dim.width-width)/2,(dim.height-height)/2);
			
			///////
			setVisible(true);
			setResizable(false);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(Java.isSelected())
		{
			QuestionInfo.setVisible(false);
			CppPanel.setVisible(false);
			CPanel.setVisible(false);
			JavaPanel.setVisible(true);
			frameInfo.setText("Java Questions");
		}
		if(CPlus.isSelected())
		{
			QuestionInfo.setVisible(false);
			JavaPanel.setVisible(false);
			CPanel.setVisible(false);
			CppPanel.setVisible(true);
			frameInfo.setText("C++ Questions");
		}
		if(C.isSelected())
		{
			QuestionInfo.setVisible(false);
			CppPanel.setVisible(false);
			JavaPanel.setVisible(false);
			CPanel.setVisible(true);
			frameInfo.setText("C Questions");
		}
		
	}
	
	public static void main(String[] args) {
		new AdminQuestions();

	}
	

}
