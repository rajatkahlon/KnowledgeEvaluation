/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/*

You have to change in 2 places only 
1. Line no 32
2. Line no 43

*/


import java.sql.*;
public class CreateTables {
// JDBC driver name and database URL
static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
static final String DB_URL = "jdbc:mysql://localhost/STUDENTS";
// Database credentials
static final String USER = "username";

static final String PASS = "password";
public static void main(String[] args) {
Connection conn = null,conn1 = null;
Statement stmt = null;
try{
//STEP 2: Register JDBC driver
Class.forName("com.mysql.jdbc.Driver");
//STEP 3: Open a connection
System.out.println("Connecting to a selected database...");
//conn = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "system");
conn = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "rajat");
//String sql3 = "CREATE database knowledgedatabase ";
//stmt = conn.createStatement();
//stmt.executeUpdate(sql3);

System.out.println("Connected database successfully...");
//STEP 4: Execute a query
System.out.println("Creating table in given database...");
String sql4 = "use knowledgedatabase ";
stmt=conn.createStatement();
stmt.executeUpdate(sql4);
//conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "system");
conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "rajat");

/*String sql10 = "CREATE TABLE admin" +
		"(username VARCHAR(50) primary key," +
		"password VARCHAR(50))";
stmt.executeUpdate(sql10);
System.out.println("Created table for admin");

String sql5 = "CREATE TABLE login " +
"(firstname VARCHAR(50), " +
"middlename VARCHAR(50), " +
" lastname VARCHAR(50), " +
" qual VARCHAR(50), " +
" address VARCHAR(50), " +
" dob VARCHAR(50), " +
" contact VARCHAR(50), " +
 " email VARCHAR(50), " +
" username VARCHAR(50) primary key, " +
" password VARCHAR(50), " +
" field1 VARCHAR(50), " +
 " field2 VARCHAR(50), " +
 " field3 VARCHAR(50), " +
" javaresult VARCHAR(50), " +
" cppresult VARCHAR(50), " +
" cresult VARCHAR(50))";

stmt.executeUpdate(sql5);

String sql6 = "CREATE TABLE loginfaculty " +
"(firstname VARCHAR(50), " +
"middlename VARCHAR(50), " +
" lastname VARCHAR(50), " +
" qual VARCHAR(50), " +
" designation VARCHAR(50), " +
" address VARCHAR(50), " +
" dob VARCHAR(50), " +
" contact VARCHAR(50), " +
 " email VARCHAR(50), " +
" username VARCHAR(50) primary key, " +
" password VARCHAR(50))";
stmt.executeUpdate(sql6);*/
String sql = "CREATE TABLE javaques " +
"(ques VARCHAR(500), " +
" option1 VARCHAR(500), " +
" option2 VARCHAR(500), " +
" option3 VARCHAR(500), " +
" option4 VARCHAR(500), " +
" answer VARCHAR(500), " +
" id VARCHAR(50) NOT NULL, " +
" PRIMARY KEY ( id ))";
stmt.executeUpdate(sql);

String sql1 = "CREATE TABLE cppques " +
"(ques VARCHAR(500), " +
" option1 VARCHAR(500), " +
" option2 VARCHAR(500), " +
" option3 VARCHAR(500), " +
" option4 VARCHAR(500), " +
" answer VARCHAR(500), " +
" id VARCHAR(50) NOT NULL, " +
" PRIMARY KEY ( id ))";
stmt.executeUpdate(sql1);

String sql2 = "CREATE TABLE cques " +
"(ques VARCHAR(500), " +
" option1 VARCHAR(500), " +
" option2 VARCHAR(500), " +
" option3 VARCHAR(500), " +
" option4 VARCHAR(500), " +
" answer VARCHAR(500), " +
" id VARCHAR(50) NOT NULL, " +
" PRIMARY KEY ( id ))";
stmt.executeUpdate(sql2);

System.out.println("Created table in given database...");
}catch(SQLException se){
//Handle errors for JDBC
se.printStackTrace();
}catch(Exception e){
//Handle errors for Class.forName
e.printStackTrace();
}finally{
//finally block used to close resources
try{
if(stmt!=null)
    conn.close();
}catch(SQLException se){
}// do nothing
try{
if(conn!=null)
conn.close();
}catch(SQLException se){
se.printStackTrace();
}//end finally try
}//end try
System.out.println("Goodbye!");
}//end main
}


