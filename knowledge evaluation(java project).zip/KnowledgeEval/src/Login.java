import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;
import java.util.function.UnaryOperator;

import javax.jws.Oneway;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;



public class Login extends JFrame implements ActionListener{
	
	public static String user1;
	JLabel back = new JLabel(" ");
	JLabel log = new JLabel(" ");
	JLabel username = new JLabel("Username");
	JTextField unme = new JTextField();
	JLabel pwsd = new JLabel("Password");
	JPasswordField pfld = new JPasswordField();
	JRadioButton admin,faculty,student; 
	JButton submit = new JButton("SUBMIT");
	JButton exit = new JButton("EXIT");
	JButton newReg = new JButton("NEW REGISTRATION");
	
	String user,password;
	
	public Login()
	{
		setBounds(0, 0, 600, 500);
		setTitle("Login");
		setLayout(null);
		/////
		back.setBounds(0, 0, 600, 500);
		ImageIcon bac = new ImageIcon("imgs/background.jpeg");
		back.setIcon(bac);
		add(back);
		log.setBounds(200, 30, 200, 50);
		ImageIcon labl = new ImageIcon("imgs/login.jpeg");
		log.setIcon(labl);
		back.add(log);
		
		ButtonGroup bg = new ButtonGroup();
		admin = new JRadioButton("ADMIN");
		faculty = new JRadioButton("FACULTY");
		student = new JRadioButton("STUDENT");
		
		admin.setBounds(50, 120, 100, 30);
		
		faculty.setBounds(190, 120, 100, 30);
	    
		student.setBounds(320, 120, 100, 30);
		
		bg.add(admin);
		bg.add(faculty);
		bg.add(student);
		
		admin.addActionListener(this);
		back.add(admin);
	    back.add(faculty);
		back.add(student);
		
		username.setBounds(50, 190, 100,30);
		back.add(username);
		unme.setBounds(200, 190, 200, 30);
		unme.setHorizontalAlignment(unme.CENTER);
		back.add(unme);
		pwsd.setBounds(50, 260, 100, 30);
		back.add(pwsd);
		pfld.setBounds(200, 260, 200, 30);
		
	    pfld.setHorizontalAlignment(pfld.CENTER);
		back.add(pfld);
		
		submit.setBounds(50, 350, 150, 30);
		ImageIcon up = new ImageIcon("imgs/thumbsup.jpeg");
      	submit.setIcon(up);
		submit.addActionListener(this);
		back.add(submit);
		
		exit.setBounds(220, 350, 150, 30);
		ImageIcon down = new ImageIcon("imgs/exitdoor.png");
      	exit.setIcon(down);
		exit.addActionListener(this);
		back.add(exit);
		
		newReg.setBounds(390, 350, 190, 30);
		ImageIcon reg = new ImageIcon("imgs/registration.jpeg");
      	newReg.setIcon(reg);
		newReg.addActionListener(this);
		back.add(newReg);
		
		////////
		int width=0;int height =0;
		if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
		{	width=640;height=460;}
		else
		{
		width=720;height=540;	
		}
		Dimension dim= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((dim.width-width)/2,(dim.height-height)/2);
		///////
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(admin.isSelected())
		{
			new admin();
			this.setVisible(false);
		}
		if(e.getSource()==submit)
		{
		if(faculty.isSelected())
		{

			if(!unme.getText().trim().equals("")||!pfld.getText().trim().equals(""))
			{
				Connection con = CreateConnection.connect();
				user = unme.getText();
				password = pfld.getText();
				try {
					PreparedStatement ps = con.prepareStatement("Select username,password from loginfaculty");
					
					ResultSet rs = ps.executeQuery();
					boolean flag =false;
					while(rs.next())
					{
						if(user.equals(rs.getObject(1))&&password.equals(rs.getObject(2)))
						{
							flag=true;
							
								break;
						}
							
							
						
						else
						{
							flag=false;
							
						}
					}
					if(flag==true)
					{
						JOptionPane.showMessageDialog(null, "Login Successful");
						
						PreparedStatement pstmt = con.prepareStatement("Select username from login");
						
						 ResultSet rs1 = pstmt.executeQuery();
						 boolean flg = false;
						// ArrayList<String> al = new ArrayList<String>();
						 Vector<String> v = new Vector<String>();
						while(rs1.next())
						{
						
						//al.add(rs1.getString(1));
						v.add(rs1.getString(1));
						
						flg = true;
						}
						
						//System.out.println(v);
						
						
						
						if(flg==true)
						{
							
							//new SelectStudent(al);
							new SelectStudent(v);
							this.dispose();
						}
					}
				 if(flag==false)
					{
					 JOptionPane.showMessageDialog(null, "Please enter the correct Username and password");
					 unme.setText("");
					 pfld.setText("");
					 
					}
				}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Please fill all the fields");
			}

			
		}
			else if(student.isSelected())
			{
				Connection con = CreateConnection.connect();
				user = unme.getText();
				password = pfld.getText();
				try {
					PreparedStatement ps = con.prepareStatement("Select username,password from login");
					
					ResultSet rs = ps.executeQuery();
					boolean flag = false;
					while(rs.next())
					{
						if(user.equals(rs.getObject(1))&&password.equals(rs.getObject(2)))
						{
							flag=true;
							
							break;
						}
						else
						{
							flag=false;
							
						}
						
					}
					
					if(flag==true)
					{
						JOptionPane.showMessageDialog(null, "Login Successful");
						
						new SelectFld((String) rs.getObject(1));
						
						
						user1 = (String) rs.getObject(1);
					//	System.out.println(user1);
						
						this.setVisible(false);
						
					}
					if(flag==false)
					{
						JOptionPane.showMessageDialog(null, "Please enter correct username and Password");
						unme.setText("");
						 pfld.setText("");
					}
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}}
				
		     else
			{
				JOptionPane.showMessageDialog(null, "please select your Designation", "invalid field", JOptionPane.INFORMATION_MESSAGE);
			}
	}
		
		if(e.getSource()==newReg)
		{
			if(student.isSelected())
			{
				
					new RegistStudent();
					this.dispose();
				
			
			}
			else if(faculty.isSelected())
			{
				
					new RegisFaculty();
					this.dispose();

			}
			else
			{
				JOptionPane.showMessageDialog(null, "please select your Designation", "invalid field", JOptionPane.INFORMATION_MESSAGE);
			}
		}
		if(e.getSource()==exit)
		{
			this.dispose();
		}
		
		
}
	public static void main(String[] args) {
		  Login login= new Login();
    
	}

}
