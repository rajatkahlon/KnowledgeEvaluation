
import java.awt. *;
import java.awt. event.*;
import javax.swing.*;
import java.sql.*;



class QuestionSeries2{
   
static String info ="C++ Online Test Week  \n \nINSTRUCTIONS:\nThere are 25 questions in this test and 30 minutes to complete them all.\nThe finish button is highlighted in blue when you reach the end of the test. \nClicking the finish button will display the results with the correct answers marked in light red.  \n \nThe timecounter  begins when you click on the 'start' button \n \nBest of luck!\n";
    

static String []question ={
"Question 1:\n"+QuestionFetch.q1+"\n",
"Question 2:\n"+QuestionFetch.q2+"\n",
"Question 3: \n"+QuestionFetch.q3+"\n",
"Question 4:\n"+QuestionFetch.q4+"\n",
"Question 5:\n"+QuestionFetch.q5+"\n",
"Question 6:\n"+QuestionFetch.q6+"\n",
"Question 7:\n"+QuestionFetch.q7+"\n",
"Question 8:\n"+QuestionFetch.q8+"\n",
"Question 9:\n"+QuestionFetch.q9+"\n",
"Question 10:\n"+QuestionFetch.q10+"\n",
"Question 11:\n"+QuestionFetch.q11+"\n",
"Question 12:\n"+QuestionFetch.q12+"\n",
"Question 13:\n"+QuestionFetch.q13+"\n",
"Question 14:\n"+QuestionFetch.q14+"\n",
"Question 15:\n"+QuestionFetch.q15+"\n",
"Question 16:\n"+QuestionFetch.q16+"\n",
"Question 17:\n"+QuestionFetch.q17+"\n",
"Question 18:\n"+QuestionFetch.q18+"\n",
"Question 19:\n"+QuestionFetch.q19+"\n",
"Question 20:\n"+QuestionFetch.q20+"\n",
"Question 21:\n"+QuestionFetch.q21+"\n",
"Question 22:\n"+QuestionFetch.q22+"\n",
"Question 23:\n"+QuestionFetch.q23+"\n",
"Question 24:\n"+QuestionFetch.q24+"\n",
"Question 25:\n "+QuestionFetch.q25+"\n"
};


static String [][]answers ={{""+QuestionFetch.q1o1+"\n", ""+QuestionFetch.q1o2+"\n"," "+QuestionFetch.q1o3+"\n",""+QuestionFetch.q1o4+"\n"},{""+QuestionFetch.q2o1+"\n"," "+QuestionFetch.q2o2+"\n"," "+QuestionFetch.q2o3+"\n"," "+QuestionFetch.q2o4+"\n"},{""+QuestionFetch.q3o1+"\n", ""+QuestionFetch.q3o2+"\n"," "+QuestionFetch.q3o3+"\n",""+QuestionFetch.q3o4+" "},{""+QuestionFetch.q4o1+"\n", ""+QuestionFetch.q4o2+"\n"," "+QuestionFetch.q4o3+"\n",""+QuestionFetch.q4o4+""},{" "+QuestionFetch.q5o1+"\n", ""+QuestionFetch.q5o2+"\n"," "+QuestionFetch.q5o3+"\n",""+QuestionFetch.q5o4+""},{""+QuestionFetch.q6o1+"\n", ""+QuestionFetch.q6o2+"\n"," "+QuestionFetch.q6o3+"\n",""+QuestionFetch.q6o4+""},{""+QuestionFetch.q7o1+"\n", ""+QuestionFetch.q7o2+"\n"," "+QuestionFetch.q7o3+"\n",""+QuestionFetch.q7o4+""},{" "+QuestionFetch.q8o1+"\n", ""+QuestionFetch.q8o2+"\n"," "+QuestionFetch.q8o3+"\n",""+QuestionFetch.q8o4+""},{" "+QuestionFetch.q9o1+"\n", ""+QuestionFetch.q9o2+"\n"," "+QuestionFetch.q9o3+"\n",""+QuestionFetch.q9o4+""},{""+QuestionFetch.q10o1+"\n", ""+QuestionFetch.q10o2+"\n"," "+QuestionFetch.q10o3+"\n",""+QuestionFetch.q10o4+""},{""+QuestionFetch.q11o1+"\n", ""+QuestionFetch.q11o2+"\n"," "+QuestionFetch.q11o3+"\n",""+QuestionFetch.q11o4+""},{""+QuestionFetch.q12o1+"\n", ""+QuestionFetch.q12o2+"\n"," "+QuestionFetch.q12o3+"\n",""+QuestionFetch.q12o4+""},{""+QuestionFetch.q13o1+"\n", ""+QuestionFetch.q13o2+"\n"," "+QuestionFetch.q13o3+"\n",""+QuestionFetch.q13o4+""},{""+QuestionFetch.q14o1+"\n", ""+QuestionFetch.q14o2+"\n"," "+QuestionFetch.q14o3+"\n",""+QuestionFetch.q14o4+""},{""+QuestionFetch.q15o1+"\n", ""+QuestionFetch.q15o2+"\n"," "+QuestionFetch.q15o3+"\n",""+QuestionFetch.q15o4+""},{""+QuestionFetch.q16o1+"\n", ""+QuestionFetch.q16o2+"\n"," "+QuestionFetch.q16o3+"\n",""+QuestionFetch.q16o4+""},{""+QuestionFetch.q17o1+"\n", ""+QuestionFetch.q17o2+"\n"," "+QuestionFetch.q17o3+"\n",""+QuestionFetch.q17o4+""},{""+QuestionFetch.q18o1+"\n", ""+QuestionFetch.q18o2+"\n"," "+QuestionFetch.q18o3+"\n",""+QuestionFetch.q18o4+""},{""+QuestionFetch.q19o1+"\n", ""+QuestionFetch.q19o2+"\n"," "+QuestionFetch.q19o3+"\n",""+QuestionFetch.q19o4+""},{""+QuestionFetch.q20o1+"\n", ""+QuestionFetch.q20o2+"\n"," "+QuestionFetch.q20o3+"\n",""+QuestionFetch.q20o4+""},{""+QuestionFetch.q21o1+"\n", ""+QuestionFetch.q21o2+"\n"," "+QuestionFetch.q21o3+"\n",""+QuestionFetch.q21o4+""},{""+QuestionFetch.q22o1+"\n", ""+QuestionFetch.q22o2+"\n"," "+QuestionFetch.q22o3+"\n",""+QuestionFetch.q22o4+""},{""+QuestionFetch.q23o1+"\n", ""+QuestionFetch.q23o2+"\n"," "+QuestionFetch.q23o3+"\n",""+QuestionFetch.q23o4+""},{""+QuestionFetch.q24o1+"\n", ""+QuestionFetch.q24o2+"\n"," "+QuestionFetch.q24o3+"\n",""+QuestionFetch.q24o4+""},{""+QuestionFetch.q25o1+"\n", ""+QuestionFetch.q25o2+"\n"," "+QuestionFetch.q25o3+"\n",""+QuestionFetch.q25o4+""} };

static int []n = {2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
static String []choice= {""+QuestionFetch.ans1+"",""+QuestionFetch.ans2+"",""+QuestionFetch.ans3+"",""+QuestionFetch.ans4+"",""+QuestionFetch.ans5+"",""+QuestionFetch.ans6+"",""+QuestionFetch.ans7+"",""+QuestionFetch.ans8+"",""+QuestionFetch.ans9+"",""+QuestionFetch.ans10+"",""+QuestionFetch.ans11+"",""+QuestionFetch.ans12+"",""+QuestionFetch.ans13+"",""+QuestionFetch.ans14+"",""+QuestionFetch.ans15+"",""+QuestionFetch.ans16+"",""+QuestionFetch.ans17+"",""+QuestionFetch.ans18+"",""+QuestionFetch.ans19+"",""+QuestionFetch.ans20+"",""+QuestionFetch.ans21+"",""+QuestionFetch.ans22+"",""+QuestionFetch.ans23+"",""+QuestionFetch.ans24+"",""+QuestionFetch.ans25+""};
static int tally = choice.length;
static String testtitle="C++ Programming Online Test";
static int timeLimit =30;
static int passMark = 15;

}


/* OnlineTest class */

public class OnlineTest2 extends JFrame{
    
    static String studentName ="";
    static int TOTAL=0;
  
	static {
	try{
	TOTAL = QuestionSeries2.tally;		
	/* 	The input window */
          studentName=new Login().user1;
	//studentname = JOptionPane.showInputDialog("Enter your ID: ");
	if(studentName.length() < 1) studentName = "Anonymous   ";
	else studentName = studentName.trim() + " ";
      
	}catch(NullPointerException e){ System.exit(0); }
	}	

    	int seconds, minutes;
    	int quesnum, itemCheck, mark; 
	final String TESTTITLE = QuestionSeries2.testtitle;
    	final int TIMELIMIT = QuestionSeries2.timeLimit;
    	final int PASS = QuestionSeries2.passMark;
    	String []answers = new String[TOTAL];
	JButton []choice_button = new JButton[6];
	JTextArea answerboxes[] = new JTextArea[4];
	JCheckBox []boxes = new JCheckBox[4];
    	JTextPane pane = new JTextPane();
	JLabel student, choose, message, timecounter, testresult;
    	boolean start_test, check_answer, allowRestart, finishtest;
	OnlineTest2.Northwindow panelNorth = new OnlineTest2.Northwindow();
	OnlineTest2.Southwindow panelSouth = new OnlineTest2.Southwindow();
	OnlineTest2.Centerwindow panelCenter = new OnlineTest2.Centerwindow();
       

/*  OnlineTest Constructor */
	public OnlineTest2() throws SQLException{
            for (int i=0; i<TOTAL; i++) answers[i] ="";
		getContentPane().setLayout(new BorderLayout() );
		getContentPane().add("North", panelNorth);
		getContentPane().add("South", panelSouth);
		getContentPane().add("Center", panelCenter);
		int width = 0, height=0; 
	        if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799){width=		640; 		height=460; }
	        else {width=720; height=540; }
		setSize(width,height);
		Dimension dim = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((dim.width-width)/2, (dim.height-height)/2);
	}

/**
**  Northwindow class
**/

class Northwindow extends JPanel{

/**
**  Northwindow constructor 
**/
    public Northwindow(){
		setLayout(new GridLayout(2,2));
		setBackground(new Color(230, 230, 255));
		student = new JLabel("\t Welcome : "+studentName+" to the Online C++ Test");
		student.setFont(new Font("",Font.BOLD,16) );
		message = new JLabel();
		message.setForeground(Color.blue);
                add(student);
		add(message);
		add(new JLabel("               ") );
		add(new JLabel("               ") );
        setBorder(BorderFactory.createEtchedBorder() );
	}
}

/**
**  Southwindow class
**/
class Southwindow extends JPanel{
	public Southwindow(){
		String []key = {"","start:","next:","finish:","check next:","check previous:"};
			for(int i=0; i<choice_button.length; i++)
                   {
				choice_button[i] = new JButton(key[i]);
				choice_button[i].addActionListener(new OnlineTest2.ActionHandler() );
				if(i !=0)add(choice_button[i]);
			  }
        setBorder(BorderFactory.createEtchedBorder() );
	}
    }

/**
**  Centerwindow class 
**/
class Centerwindow extends JPanel{

	public Centerwindow(){
		setLayout(new GridLayout(1,2) );
		JScrollPane west = new JScrollPane(pane);       
		pane.setForeground(Color.red);	       
   		pane.setFont(new Font ("monospaced",0,12) );
		pane.setText(QuestionSeries2.info);
		pane.setEditable(false);
		JPanel east = new JPanel();
		east.setLayout(new BorderLayout() );	
		JPanel northEast = new JPanel();
		northEast.setBackground(new Color(230, 230, 255) ); 
		east.add("North", northEast);
		JPanel westEast = new JPanel();
		westEast.setLayout(new GridLayout(6,1) );
		east.add("West", westEast);
		JPanel centerEast = new JPanel();
		centerEast.setLayout(new GridLayout(6,1) );
		centerEast.setBackground(new Color(255,255,200));
		east.add("Center", centerEast);       
			timecounter = new JLabel("     There are "+TOTAL+" questions in total");
			timecounter.setFont(new Font ("Arial",Font.BOLD,16) );
			timecounter.setForeground(new Color(0,90,20) );
			northEast.add(timecounter);
			westEast.add(new JLabel(" "));
        String []boxs = {" A ", " B ", " C ", " D "};
			for(int i=0; i<boxes.length; i++) { 
				boxes[i] = new JCheckBox(boxs[i]);
				boxes[i].addItemListener(new OnlineTest2.ItemHandler() );
				westEast.add(boxes[i]);
			}
        westEast.add(new JLabel() );
		choose = new JLabel("    CHOOSE CORRECT ANSWERS");
		choose.setBorder(BorderFactory.createEtchedBorder() );
		centerEast.add(choose);
        JScrollPane panes[] = new JScrollPane[4];
			for(int i=0; i<answerboxes.length; i++){
				answerboxes[i] = new JTextArea();
			    answerboxes[i].setBorder(BorderFactory.createEtchedBorder() );
				answerboxes[i].setEditable(false);
				answerboxes[i].setBackground(Color.white);
				answerboxes[i].setFont(new Font("",0,12) );
	            answerboxes[i].setLineWrap(true);      
                answerboxes[i].setWrapStyleWord(true);
                panes[i] = new JScrollPane(answerboxes[i]);
			    centerEast.add(panes[i]);
			}
		if(TIMELIMIT >0)testresult = new JLabel(studentName+",   You have only : "+TIMELIMIT+" minutes to complete.");   
		else testresult = new JLabel("     There is no time limit for this test");
		testresult.setBorder(BorderFactory.createEtchedBorder() );
		centerEast.add(testresult);
	add(west);
	add(east);
	}
    }

/**
**  ActionHandler class to handle all the action events from the buttons. 
**/

class ActionHandler implements ActionListener{

/* actionPerformed method */
	public void actionPerformed(ActionEvent evt){
	  String source = evt.getActionCommand();
		if(source.equals("start:")){
			choice_button[1].setVisible(false);
			start_test=true;
			allowRestart=true;
            if(TIMELIMIT >0)new Timer(); // inner Timer class 
			panelSouth.remove(choice_button[1]); //start
            displayquestion();            
        }
	if(start_test){
		if(source.equals("previous:"))  {            			
			recordanswer();
			quesnum--;
    		if(quesnum ==  -1) quesnum=TOTAL-1;
			checkteststatus();
            displayquestion(); 
		}
		if(source.equals("next:")) {
			recordanswer();
			quesnum++;            
			if(quesnum ==  TOTAL-1) finishtest=true;
			if(quesnum ==  TOTAL) quesnum=0;
            checkteststatus();
            displayquestion(); 
		}
		if(source.equals("finish:")) {
			if (finishtest){
				recordanswer();
				quesnum = 0;

				choice_button[4].setBackground(Color.lightGray);
				timecounter.setForeground(Color.blue);
				timecounter.setFont(new Font ("Arial",0,14) );
				start_test=false; 
				check_answer=true;
				panelSouth.add(choice_button[0]);
				mark_ques();
				displayquestion();
				checkteststatus();
				calculateResult();
			}
			else  JOptionPane.showMessageDialog(null,"Cycle through all questions before pressing finish",
																 "User Message",JOptionPane.INFORMATION_MESSAGE);
		}
	} 

	if (check_answer){
		if(source.equals("check next:")) {
			quesnum++;
			if(quesnum ==  TOTAL) quesnum=0;
			mark_ques();
			displayquestion();
			checkteststatus();
		}
		if(source.equals("check previous:")) {
			quesnum--;
			if(quesnum ==  -1) quesnum=TOTAL-1;
			mark_ques();
			displayquestion();
			checkteststatus();
		}
	}
	validate();        
	}

/* Timer class */

class Timer extends Thread implements Runnable{
	public Timer(){
		new Thread(this).start();
	}

    public void run() {
		while(start_test){
            try {
               Thread.sleep(1000);
               seconds++;
				if(seconds % 60 == 0 && seconds != 0){
                    seconds -= 60;
                    minutes++;
				}
				timecounter.setText("    Time Counter:  "+minutes+" mins : "+seconds+" secs ");
				if(minutes==TIMELIMIT){
					start_test=false;
					endTest();
                }
		    }
            catch(InterruptedException ex)  { System.out.print(ex); }
		}
    }
}

/* checkteststatus method */

		public void checkteststatus(){
		if((quesnum ==  TOTAL-1)&&(start_test))choice_button[3].setBackground(Color.green);
		else choice_button[4].setBackground(Color.lightGray);
      	  if(answers[quesnum].length() >0){ 
			for(int i=0; i<answers[quesnum].length(); i++)
			boxes[Integer.parseInt(answers[quesnum].substring(i,i+1) )-1].setSelected			(true);
		}
		else for(int i=0; i<boxes.length; i++)boxes[i].setSelected(false);
		}

/* displayquestion method */

	public void displayquestion(){
        int j = quesnum+1;
		pane.setText(QuestionSeries2.question[quesnum]);
		if(start_test)message.setText("Question "+j+" out of "+TOTAL);
        for (int i=0; i<4; i++)answerboxes[i].setText(QuestionSeries2.answers[quesnum][i]);
		if(start_test){
            String temp="";
			if(QuestionSeries2.n[quesnum]==1) temp="<html>&nbsp;&nbsp;&nbsp;Choose only 		<b>ONE</b>  Option</html>";
			else if(QuestionSeries2.n[quesnum]==2) temp="<html>&nbsp;&nbsp;Choose only <b>ONE		</b> Options</html>";
		else if(QuestionSeries2.n[quesnum]==3) temp="<html>&nbsp;&nbsp;Choose <b>THREE</b> 		Options</html>";
            else temp="<html>&nbsp;&nbsp;<b>ALL are true</b> true</html>";
		choose.setText(temp);
		}
		else {
		timecounter.setText("    Your choices are shown in the boxes");
            choose.setText("    Correct answers are marked in light red.");
		}
	}

/* record answer method */

	public void recordanswer(){
		String tmp = "";
		for(int i=0; i<boxes.length; i++) if(boxes[i].isSelected() ) tmp +=i+1;
        answers[quesnum] = tmp;
    }

/* endTest method */ 

	public void endTest(){
		message.setText("TIME OVER: please press 'finish'");
        choice_button[2].setEnabled(false); 
        choice_button[3].setEnabled(false); 
        choice_button[4].setEnabled(true); 
	}

/* mark_ques() method to highlight correct answers */

	public void mark_ques(){
		for(int i=0; i<answerboxes.length; i++) answerboxes[i].setBackground(Color.white);
		for(int i=0; i<QuestionSeries2.choice[quesnum].length(); i++)
			answerboxes[Integer.parseInt(QuestionSeries2.choice[quesnum].substring(i,i+1))-1].setBackground(Color.red);
		if(QuestionSeries2.choice[quesnum].equals(answers[quesnum])) message.setText("Answer correct, well done!");
		else message.setText("Sorry, you got this one wrong.");
	}


	public void calculateResult(){
		mark=0;
		double temp=0.0;
        java.text.DecimalFormat df = new java.text.DecimalFormat("#0.#");
		for(int i=0; i<TOTAL; i++)if(QuestionSeries2.choice[i].equals(answers[i]))mark++;
		temp=(double)mark;

	 String atm=""+mark;
         
         atm.toString();
        

	try
	{
	 
        Connection con = CreateConnection.connect();
         System.out.println("Connected1...........");
         Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
         ResultSet rs=st.executeQuery("select * from login where username='"+studentName+"'");
         rs.next();
         rs.updateString("cppresult",atm);
         rs.updateRow();
         
		
	con.close();

	}
	catch(Exception e)
	{System.out.print(e);}


		if(temp/TOTAL*100 >=PASS) testresult.setText("  Well done "+studentName.substring(0,studentName.indexOf(' ') )+", you passed");
		else testresult.setText("  Better luck next time "+studentName.substring(0,studentName.indexOf(' ') ) );
		student.setText(" Final score for "+studentName+":  "+mark+" out of "+TOTAL+":  "+df.format(temp/TOTAL*100)+"%");
		new OnlineTest2.Resultwindow().show();
	}
    }

/* Resultwindow class */

class Resultwindow extends JFrame{
		Resultwindow() {
      	super( studentName+" results: " +(mark*100/TOTAL >=PASS?"PASS":"FAIL") );
  		Container cont = getContentPane();
		cont.setLayout(new GridLayout(TOTAL/2+3,5,2,5) );
		cont.setBackground(new Color(255,220,255) );
		cont.add(new JLabel("  "+"Marks:    "+mark+"/"+TOTAL+": "+"Percentage:  "+(mark*100/TOTAL)+"%") );
           for(int i=0; i<3; i++)cont.add(new JLabel() );
      	  String temp[] = new String[TOTAL];
			for(int i=0; i<TOTAL; i++){
				if(QuestionSeries2.choice[i].equals(answers[i])) temp[i]="correct";
				else temp[i]="wrong";
			}
			for(int i=0; i<TOTAL; i++) cont.add(new JLabel("  Question "+(i+1)+":  "+temp		[i]) );
		pack();
		setLocation(200,200);
	}
}

/* ItemHandler class */

class ItemHandler implements ItemListener{
	public void itemStateChanged(ItemEvent evt){
	  if(start_test){
		for(int i=0; i<boxes.length; i++) if(boxes[i].isSelected() ) itemCheck++; 
		if(itemCheck > QuestionSeries2.n[quesnum]){
			java.awt.Toolkit.getDefaultToolkit().beep();
            if(QuestionSeries2.n[quesnum]==1)	JOptionPane.showMessageDialog(null,"<html><font 		size='4' color='00308a'><center>"+
      	"There is only "+QuestionSeries2.n[quesnum]+" possible<br> answer to question "+(quesnum+1)+
                    "<html>","User Information Message",JOptionPane.INFORMATION_MESSAGE);
			else JOptionPane.showMessageDialog(null,"<html><font size='4' color='00308a'><center>"+
                    "There are only "+QuestionSeries2.n[quesnum]+" possible<br> answers to question "+(quesnum+1)+
                    "<html>","User Information Message",JOptionPane.INFORMATION_MESSAGE);
		}
		itemCheck=0;
	  }	  
	}
}

/*  main method 

	public static void main(String [] args) throws SQLException{
		new OnlineTest2();
		OnlineTest2 frame = new OnlineTest2();
		frame.setTitle("    "+QuestionSeries2.testtitle);
		frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
		frame.setVisible(true);
                              
    }*/
       
}
class QuestionFetch
{
     Connection con=null;
        Statement st=null;
        ResultSet rs=null;
     static String q1,q1o1,q1o2,q1o3,q1o4,ans1,q2,q2o1,q2o2,q2o3,q2o4,ans2,q3,q3o1,q3o2,q3o3,q3o4,ans3,q4,q4o1,q4o2,q4o3,q4o4,ans4,q5,q5o1,q5o2,q5o3,q5o4,ans5,q6,q6o1,q6o2,q6o3,q6o4,ans6,q7,q7o1,q7o2,q7o3,q7o4,ans7,q8,q8o1,q8o2,q8o3,q8o4,ans8,q9,q9o1,q9o2,q9o3,q9o4,ans9,q10,q10o1,q10o2,q10o3,q10o4,ans10,q11,q11o1,q11o2,q11o3,q11o4,ans11,q12,q12o1,q12o2,q12o3,q12o4,ans12,q13,q13o1,q13o2,q13o3,q13o4,ans13,q14,q14o1,q14o2,q14o3,q14o4,ans14,q15,q15o1,q15o2,q15o3,q15o4,ans15,q16,q16o1,q16o2,q16o3,q16o4,ans16,q17,q17o1,q17o2,q17o3,q17o4,ans17,q18,q18o1,q18o2,q18o3,q18o4,ans18,q19,q19o1,q19o2,q19o3,q19o4,ans19,q20,q20o1,q20o2,q20o3,q20o4,ans20,q21,q21o1,q21o2,q21o3,q21o4,ans21,q22,q22o1,q22o2,q22o3,q22o4,ans22,q23,q23o1,q23o2,q23o3,q23o4,ans23,q24,q24o1,q24o2,q24o3,q24o4,ans24,q25,q25o1,q25o2,q25o3,q25o4,ans25=null;
     public QuestionFetch() throws SQLException
             {
                    try
	{
	 
          con = CreateConnection.connect();
         System.out.println("Connected..................");
         st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
            rs=st.executeQuery("select * from cppques");
             System.out.println("result set created");
            rs.next();
         String id1=rs.getString("id");
     //    System.out.println("id1........."+id1);
          
                     q1=rs.getString("ques");
                     q1o1=rs.getString("option1");
                     q1o2=rs.getString("option2");
                     q1o3=rs.getString("option3");
                     q1o4=rs.getString("option4");
                     ans1=rs.getString("answer");
                     System.out.println(q1);
                     
             rs.next();
             String id2=rs.getString("id");
                System.out.println(id2);
            
                     q2=rs.getString("ques");
                     q2o1=rs.getString("option1");
                     q2o2=rs.getString("option2");
                     q2o3=rs.getString("option3");
                     q2o4=rs.getString("option4");
                     ans2=rs.getString("answer");
                        System.out.print(q2);
                      rs.next();
             String id3=rs.getString("id");
       //    System.out.println("id2........."+id3);
                     q3=rs.getString("ques");
                     q3o1=rs.getString("option1");
                     q3o3=rs.getString("option3");
                     q3o4=rs.getString("option4");
                     ans3=rs.getString("answer");
                     
                      rs.next();
             String id4=rs.getString("id");
           //  System.out.println("id2........."+id4);
                     q4=rs.getString("ques");
                     q4o1=rs.getString("option1");
                     q4o2=rs.getString("option2");
                     q4o3=rs.getString("option3");
                     q4o4=rs.getString("option4");
                     ans4=rs.getString("answer");
                        System.out.print(q4);
                      rs.next();
             String id5=rs.getString("id");
         //    System.out.println("id2........."+id5);
                     q5=rs.getString("ques");
                     q5o1=rs.getString("option1");
                     q5o2=rs.getString("option2");
                     q5o3=rs.getString("option3");
                     q5o4=rs.getString("option4");
                     ans5=rs.getString("answer");
                     
                      rs.next();
             String id6=rs.getString("id");
         //    System.out.println("id2........."+id6);
                     q6=rs.getString("ques");
                     q6o1=rs.getString("option1");
                     q6o2=rs.getString("option2");
                     q6o3=rs.getString("option3");
                     q6o4=rs.getString("option4");
                     ans6=rs.getString("answer");
                     
                      rs.next();
             String id7=rs.getString("id");
         //    System.out.println("id2........."+id7);
                     q7=rs.getString("ques");
                     q7o1=rs.getString("option1");
                     q7o2=rs.getString("option2");
                     q7o3=rs.getString("option3");
                     q7o4=rs.getString("option4");
                     ans7=rs.getString("answer");
                        System.out.print(q7);
                      rs.next();
             String id8=rs.getString("id");
         //    System.out.println("id2........."+id8);
                     q8=rs.getString("ques");
                     q8o1=rs.getString("option1");
                     q8o2=rs.getString("option2");
                     q8o3=rs.getString("option3");
                     q8o4=rs.getString("option4");
                     ans8=rs.getString("answer");
                     
                      rs.next();
             String id9=rs.getString("id");
           //  System.out.println("id2........."+id9);
                     q9=rs.getString("ques");
                     q9o1=rs.getString("option1");
                     q9o2=rs.getString("option2");
                     q9o3=rs.getString("option3");
                     q9o4=rs.getString("option4");
                     ans9=rs.getString("answer");
                     
                      rs.next();
             String id10=rs.getString("id");
        //     System.out.println("id2........."+id10);
                     q10=rs.getString("ques");
                     q10o1=rs.getString("option1");
                     q10o2=rs.getString("option2");
                     q10o3=rs.getString("option3");
                     q10o4=rs.getString("option4");
                     ans10=rs.getString("answer");
                     
                     rs.next();
             String id11=rs.getString("id");
          // System.out.println("id2........."+id11);
                    q11=rs.getString("ques");
                     q11o1=rs.getString("option1");
                     q11o2=rs.getString("option2");
                     q11o3=rs.getString("option3");
                     q11o4=rs.getString("option4");
                     ans11=rs.getString("answer");
                     
                     rs.next();
             String id12=rs.getString("id");
           //  System.out.println("id2........."+id12);
                     q12=rs.getString("ques");
                     q12o1=rs.getString("option1");
                     q12o2=rs.getString("option2");
                     q12o3=rs.getString("option3");
                     q12o4=rs.getString("option4");
                     ans12=rs.getString("answer");
                     
                     rs.next();
             String id13=rs.getString("id");
          //   System.out.println("id2........."+id13);
                     q13=rs.getString("ques");
                     q13o1=rs.getString("option1");
                     q13o2=rs.getString("option2");
                     q13o3=rs.getString("option3");
                     q13o4=rs.getString("option4");
                     ans13=rs.getString("answer");
                     
                     rs.next();
             String id14=rs.getString("id");
         //    System.out.println("id2........."+id14);
                     q14=rs.getString("ques");
                     q14o1=rs.getString("option1");
                     q14o2=rs.getString("option2");
                     q14o3=rs.getString("option3");
                     q14o4=rs.getString("option4");
                     ans14=rs.getString("answer");
                     
                     rs.next();
             String id15=rs.getString("id");
        //     System.out.println("id2........."+id15);
                     q15=rs.getString("ques");
                     q15o1=rs.getString("option1");
                     q15o2=rs.getString("option2");
                     q15o3=rs.getString("option3");
                     q15o4=rs.getString("option4");
                     ans15=rs.getString("answer");
                     
                     rs.next();
             String id16=rs.getString("id");
     //        System.out.println("id2........."+id16);
                     q16=rs.getString("ques");
                     q16o1=rs.getString("option1");
                     q16o2=rs.getString("option2");
                     q16o3=rs.getString("option3");
                     q16o4=rs.getString("option4");
                     ans16=rs.getString("answer");
                     
                     rs.next();
             String id17=rs.getString("id");
    //         System.out.println("id2........."+id17);
                     q17=rs.getString("ques");
                     q17o1=rs.getString("option1");
                     q17o2=rs.getString("option2");
                     q17o3=rs.getString("option3");
                     q17o4=rs.getString("option4");
                     ans17=rs.getString("answer");
                     
                     rs.next();
             String id18=rs.getString("id");
       //      System.out.println("id2........."+id18);
                     q18=rs.getString("ques");
                     q18o1=rs.getString("option1");
                     q18o2=rs.getString("option2");
                     q18o3=rs.getString("option3");
                     q18o4=rs.getString("option4");
                     ans18=rs.getString("answer");
                    
                     rs.next();
             String id19=rs.getString("id");
        //     System.out.println("id2........."+id19);
                     q19=rs.getString("ques");
                     q19o1=rs.getString("option1");
                     q19o2=rs.getString("option2");
                     q19o3=rs.getString("option3");
                     q19o4=rs.getString("option4");
                     ans19=rs.getString("answer");
                     
                     rs.next();
             String id20=rs.getString("id");
          //   System.out.println("id2........."+id20);
                     q20=rs.getString("ques");
                     q20o1=rs.getString("option1");
                     q20o2=rs.getString("option2");
                     q20o3=rs.getString("option3");
                     q20o4=rs.getString("option4");
                     ans20=rs.getString("answer");
                     
                      rs.next();
             String id21=rs.getString("id");
          //   System.out.println("id2........."+id21);
                     q21=rs.getString("ques");
                     q21o1=rs.getString("option1");
                     q21o2=rs.getString("option2");
                     q21o3=rs.getString("option3");
                     q21o4=rs.getString("option4");
                     ans21=rs.getString("answer");
                     
                       rs.next();
             String id22=rs.getString("id");
          //   System.out.println("id2........."+id22);
                     q22=rs.getString("ques");
                     q22o1=rs.getString("option1");
                     q22o2=rs.getString("option2");
                     q22o3=rs.getString("option3");
                     q22o4=rs.getString("option4");
                     ans22=rs.getString("answer");
                     
                      rs.next();
             String id23=rs.getString("id");
         //    System.out.println("id2........."+id23);
                     q23=rs.getString("ques");
                     q23o1=rs.getString("option1");
                     q23o2=rs.getString("option2");
                     q23o3=rs.getString("option3");
                     q23o4=rs.getString("option4");
                     ans23=rs.getString("answer");
                     
                      rs.next();
             String id24=rs.getString("id");
         //    System.out.println("id2........."+id24);
                     q24=rs.getString("ques");
                     q24o1=rs.getString("option1");
                     q24o2=rs.getString("option2");
                     q24o3=rs.getString("option3");
                     q24o4=rs.getString("option4");
                     ans24=rs.getString("answer");
                     
                      rs.next();
             String id25=rs.getString("id");
          //   System.out.println("id2........."+id25);
                     q25=rs.getString("ques");
                     q25o1=rs.getString("option1");
                     q25o2=rs.getString("option2");
                     q25o3=rs.getString("option3");
                     q25o4=rs.getString("option4");
                     ans25=rs.getString("answer");
             }
}