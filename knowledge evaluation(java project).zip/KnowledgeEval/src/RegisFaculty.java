import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import javax.print.attribute.standard.Media;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class RegisFaculty extends JFrame implements ActionListener{
	JLabel back = new JLabel("");
	JLabel reg = new JLabel("FACULTY REGISTRATION FORM");
	JLabel name = new JLabel("Name:");
	JTextField FstN = new JTextField();
	JTextField MleN = new JTextField();
	JTextField LstN = new JTextField();
	JLabel firstN = new JLabel("(first name)");
	JLabel midlN = new JLabel("(middle name)");
	JLabel lstN = new JLabel("(last name)");
	
	JLabel add = new JLabel("Address:");
	JTextArea addAra = new JTextArea();
	JScrollPane scr1 = new JScrollPane(addAra, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JLabel qual = new JLabel("Qualification:");
	String[] comb ={"Select your qualification","Phd","MCA","M.tech","B.tech","BCA"};
	
	JComboBox qualComb = new JComboBox(comb);
	
	JLabel desig = new JLabel("Designation:");
	String[] deg ={"Select","VC","Director","HOD","Assistant Prof."};
	JComboBox degCombo = new JComboBox(deg);
	
	JLabel dob = new JLabel("Date of Birth");
	String[] date = {"DATE"};
	JComboBox dateComb = new JComboBox(date);
	String[] newDate = new String[32];
	String[] mnth = {"MONTH"};
	JComboBox mnthComb = new JComboBox(mnth);
	String[] newMnth = new String[13];
	String[] yr ={"YEAR"};
	JComboBox yrComb = new JComboBox(yr);
	String[] newyr = new String[2001];
	
	JLabel contact = new JLabel("Contact No:");
	JTextField num = new JTextField();
	JLabel mobile = new JLabel("(mobile)");
	
	JLabel email = new JLabel("Email Id:");
	JTextField fldId = new JTextField();
	JLabel egId = new JLabel("(eg:someone@gmail.com)");
	
	JLabel username = new JLabel("UserName");
	JTextField fldName = new JTextField();
	
	JLabel pwsd = new JLabel("Password");
	JPasswordField fldPwd = new JPasswordField();
	
	JLabel conPwsd = new JLabel("Conform Password");
	JPasswordField fldConf = new JPasswordField();
	
	JButton submit = new JButton("SUBMIT");
	JButton cancel = new JButton("CANCEL");
	JButton Back = new JButton("BACK");
	
	String FirstName,MiddleName,LastName,Address,designation,Qualification,Dob,contactno,Email,User,Password;
	
	public RegisFaculty() {
		
		setBounds(300, 30, 600, 700);
		setLayout(null);
		setTitle("Faculty Registration");
		//////
		back.setBounds(0, 0, 600, 700);
		ImageIcon bac = new ImageIcon("imgs/backgroundLong.jpg");
		back.setIcon(bac);
		add(back);
		reg.setBounds(10, 10, 600, 30);
		reg.setForeground(Color.BLUE);
		reg.setFont(new Font("Algerian",0,30));
		back.add(reg);
		name.setBounds(30, 50, 100, 30);
		back.add(name);
		FstN.setBounds(150, 50, 120, 30);
		back.add(FstN);
		MleN.setBounds(280, 50, 120, 30);
		back.add(MleN);
		LstN.setBounds(410, 50, 120, 30);
		back.add(LstN);
		firstN.setBounds(150, 80, 100, 20);
		back.add(firstN);
		midlN.setBounds(280, 80, 100, 20);
		back.add(midlN);
		lstN.setBounds(410, 80, 100, 20);
		back.add(lstN);
		
		add.setBounds(30, 120, 100, 30);
		back.add(add);
		scr1.setBounds(150, 120, 400, 70);
		addAra.setLineWrap(true);
		back.add(scr1);
		qual.setBounds(30, 210, 100, 30);
		back.add(qual);
		qualComb.setBounds(150, 210, 250, 30);
		back.add(qualComb);
		
		desig.setBounds(30, 260, 100, 30);
		back.add(desig);
		degCombo.setBounds(150, 260, 200, 30);
		back.add(degCombo);
		
		dob.setBounds(30, 310, 100, 30);
		back.add(dob);
		dateComb.setBounds(150, 310, 70, 30);
        
    	for(int i=1;i<newDate.length;i++)
    	{
    	   newDate[i]=new String(String.valueOf(i));
    		dateComb.addItem(newDate[i]);
    	}
    	 back.add(dateComb);
    	mnthComb.setBounds(230, 310, 70, 30);
        back.add(mnthComb);
      	for(int i=1;i<newMnth.length;i++)
    	{
   	    newMnth[i]=new String(String.valueOf(i));
   		mnthComb.addItem(newMnth[i]);
    	}
      	
      	yrComb.setBounds(310, 310, 70, 30);
        back.add(yrComb);
      	for(int i=1980;i<newyr.length;i++)
    	{
   	    newyr[i]=new String(String.valueOf(i));
   		yrComb.addItem(newyr[i]);
    	}
      	
      	contact.setBounds(30, 350, 100, 30);
      	back.add(contact);
      	num.setBounds(150, 350, 200, 30);
      	back.add(num);
      	mobile.setBounds(360, 350, 200, 30);
      	back.add(mobile);
      	
      	email.setBounds(30, 400, 100, 30);
      	back.add(email);
      	fldId.setBounds(150, 400, 200, 30);
      	back.add(fldId);
      	egId.setBounds(150, 430, 200, 20);
      	back.add(egId);
      	
      	username.setBounds(30, 470, 100, 30);
      	back.add(username);
      	fldName.setBounds(150, 470, 200, 30);
      	back.add(fldName);
      	pwsd.setBounds(30, 530, 100, 30);
      	back.add(pwsd);
      	fldPwd.setBounds(150, 530, 200, 30);
      	back.add(fldPwd);
      	conPwsd.setBounds(30, 580, 100, 30);
      	back.add(conPwsd);
      	fldConf.setBounds(150, 580, 200, 30);
      	back.add(fldConf);
      	
      	submit.setBounds(50, 630, 150, 30);
      	ImageIcon up = new ImageIcon("imgs/thumbsup.jpeg");
      	submit.setIcon(up);
      	submit.addActionListener(this);
      	back.add(submit);
      	
      	cancel.setBounds(420, 630, 150, 30);
      	ImageIcon down = new ImageIcon("imgs/thumbsdown.jpeg");
      	cancel.setIcon(down);
      	cancel.addActionListener(this);
      	back.add(cancel);
      	
      	Back.setBounds(235, 630,150, 30);
      	ImageIcon bk = new ImageIcon("imgs/back.jpeg");
      	Back.setIcon(bk);
      	Back.addActionListener(this);
      	back.add(Back);
      	
		//////
		int width=0;int height =0;
		if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
		{	width=640;height=460;}
		else
		{
		width=720;height=540;	
		}
		Dimension dim= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		//setLocation((dim.width-width)/2,(dim.height-height)/2);
		/////
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==submit)
		{
			if(!FstN.getText().equals("")&&!LstN.getText().equals("")&&!addAra.getText().equals("")&&!num.getText().equals("")&&!fldId.getText().equals("")&&!fldName.getText().equals("")&&!fldPwd.getPassword().equals("")&&!fldConf.getPassword().equals("")&&!qualComb.getSelectedItem().equals("Select your qualification")&&!dateComb.getSelectedItem().equals("DATE")&&!mnthComb.getSelectedItem().equals("MONTH")&&!yrComb.getSelectedItem().equals("YEAR")&&!degCombo.getSelectedItem().equals("Select"))
			{
				if(!Arrays.equals(fldPwd.getPassword(), fldConf.getPassword()))
						{
					JOptionPane.showMessageDialog(null, "password doesn't match!", "Re-enter password", JOptionPane.INFORMATION_MESSAGE);
					 
					    }
			  else
					{
					
						Connection con = CreateConnection.connect();
						
					try {
						User = fldName.getText();
						PreparedStatement ps = con.prepareStatement("Select username from loginfaculty");
						ResultSet rs = ps.executeQuery();
						boolean flag = true;
						while(rs.next())
						{
							if(User.equals(rs.getString(1)))
							{
								JOptionPane.showMessageDialog(null, "UserName already exits, please provide another UserName");
								flag=false;
								break;
							}
						}
						
						if(flag==true)
						{
					    User = fldName.getText();
					    FirstName = FstN.getText();
						MiddleName = MleN.getText();
						LastName = LstN.getText();
						Address = addAra.getText();
						Qualification = (String) qualComb.getSelectedItem();
						designation = (String) degCombo.getSelectedItem();
						Dob = dateComb.getSelectedItem()+"/"+mnthComb.getSelectedItem()+"/"+yrComb.getSelectedItem();
						contactno = num.getText();
					     Email = fldId.getText();
					     User = fldName.getText();
					     Password = fldPwd.getText();
						
						PreparedStatement pstmt = con.prepareStatement("insert into loginfaculty(firstname,middlename,lastname,qual,designation,address,dob,contact,email,username,password)values(?,?,?,?,?,?,?,?,?,?,?)");
						
						pstmt.setString(1, FirstName);
						pstmt.setString(2, MiddleName);
						pstmt.setString(3, LastName);
						pstmt.setString(4, Qualification);
						pstmt.setString(5, designation);
						pstmt.setString(6, Address);
						pstmt.setString(7, Dob);
						pstmt.setString(8, contactno);
						pstmt.setString(9, Email);
						pstmt.setString(10, User);
						pstmt.setString(11, Password);
						
						pstmt.executeUpdate();
						pstmt.close();
						CreateConnection.disconnect();
						JOptionPane.showMessageDialog(null, "Congratulations! you are registered");
						new Login();
						this.dispose();
						
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					}
				
			
			     }
			
			else
			{
				JOptionPane.showMessageDialog(null, "Please fill all the details", "invalid field", JOptionPane.INFORMATION_MESSAGE);
			}
						    
			
		}
		if(e.getSource()==cancel)
		{
			JOptionPane.showMessageDialog(null, "You are going to close..");
			
			this.dispose();
			}
		
	if(e.getSource()==Back)
	{
		new Login();
		this.dispose();
	}
	}

	public static void main(String[] args) {
		
    new RegisFaculty();
	}

}
