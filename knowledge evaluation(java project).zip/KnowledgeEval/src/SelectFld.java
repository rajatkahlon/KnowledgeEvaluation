import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class SelectFld extends JFrame implements ActionListener{
	
	
	
	
	String studentName="";
	JLabel back = new JLabel("");
	JLabel hello;
	JLabel select = new JLabel("Please Select a Field...");
	String[] subject = {"Select"};
	JComboBox subComb = new JComboBox<String>(subject);
	
	JButton submit = new JButton("SUBMIT");
	JButton exit = new JButton("EXIT");
	JButton Back = new JButton("BACK");
	
	String field1;
	String field2;
	String field3;
	
	public SelectFld(String s)
	{
		studentName = s;
		hello =new JLabel("HELLO: "+studentName);
		setBounds(0, 0, 600, 500);
		setLayout(null);
		//////
		back.setBounds(0, 0, 600, 500);
		ImageIcon bac = new ImageIcon("imgs/background.jpeg");
		back.setIcon(bac);
		add(back);
		hello.setBounds(10, 30, 600, 30);
		hello.setForeground(Color.BLUE);
		hello.setFont(new Font("Algerian",0,30));
		back.add(hello);
		
		select.setBounds(180, 90, 200, 40);
		back.add(select);
		
		////////////////////////////////
		////////////////////////////////
		////////////////////////////////
	   subComb.setBounds(180, 160, 200, 30);
	   
	   
	   
			
			Connection con = CreateConnection.connect();
			PreparedStatement pstmt;
			try {
				pstmt = con.prepareStatement("Select field1,field2,field3 from login where username=?");
				pstmt.setString(1, studentName);
				ResultSet rs =pstmt.executeQuery();
				rs.next();
			    field1 = rs.getString(1);
			    field2 = rs.getString(2);
			    field3 = rs.getString(3);
			    
			  if(field1!=null)
			  {
			    subComb.addItem(field1);
			  }
			  if(field2!=null)
			  {
				  subComb.addItem(field2);
			  }
			  if(field3!=null)
			  {
				  subComb.addItem(field3);
			  }
				rs.close();
				pstmt.close();
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		
	
	   back.add(subComb);
		//////////////////////////
	   /////////////////////////////
	   ///////////////////////////
	   
	   submit.setBounds(50, 300, 150, 30);
     	ImageIcon up = new ImageIcon("imgs/thumbsup.jpeg");
     	submit.setIcon(up);
     	submit.addActionListener(this);
     	back.add(submit);
     	
     	exit.setBounds(220, 300, 150, 30);
     	ImageIcon down = new ImageIcon("imgs/exitdoor.png");
     	exit.setIcon(down);
     	exit.addActionListener(this);
     	back.add(exit);
		
     	Back.setBounds(390, 300, 150, 30);
    	ImageIcon bk = new ImageIcon("imgs/back.jpeg");
      	Back.setIcon(bk);
      	Back.addActionListener(this);
      	back.add(Back);
     	
		///////
		int width=0;int height =0;
		if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
		{	width=640;height=460;}
		else
		{
		width=720;height=540;	
		}
		Dimension dim= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((dim.width-width)/2,(dim.height-height)/2);
		//////
	    setVisible(true);
	    setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	

	@Override
	public void actionPerformed(ActionEvent e) 
	{
	
		if(e.getSource()==submit)
		{
			if(subComb.getSelectedItem()==field1)
			{
				//System.out.println(field1);
				 System.out.print("JAVA Running............");
				 Connection con = CreateConnection.connect();
				try{
					new QuestionFetch1();
					
					 new OnlineTest3().setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				setVisible(false);
				 }
			
			
			else if(subComb.getSelectedItem()==field2)
			{
				 System.out.print("C++ Running.........");
			      try {
					new QuestionFetch();
					 new OnlineTest2().setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			   
			    setVisible(false);
			}
			
			else if(subComb.getSelectedItem()==field3)
			{
				 System.out.print("C Running.............");
				    try {
						new QuestionFetch3();
						 new OnlineTest4().setVisible(true);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		          
				    setVisible(false);
			}
		}
		if(e.getSource()==exit)
		{
			this.dispose();
		}
		if(e.getSource()==Back)
		{
			new Login();
			this.dispose();
		}
	}
	public static void main(String[] args) {
		new SelectFld("");

	}
}
