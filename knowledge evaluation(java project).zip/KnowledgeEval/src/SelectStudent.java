import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.w3c.dom.NameList;


public class SelectStudent extends JFrame implements ActionListener,ListSelectionListener
{

	JLabel back = new JLabel("");
	JLabel select = new JLabel("Select the subjects for Students:");
	JCheckBox Java = new JCheckBox("JAVA");
	JCheckBox CPlus = new JCheckBox("C++");
	JCheckBox C = new JCheckBox("C");
	JList<String> nameLst;
	//String[] name ={"rajat","radhika","manraj","sarb","rajinder","navdeep"}; 
	//ArrayList<String>name;
	Vector<String> name;
	
	JButton submit = new JButton("SUBMIT");
	JButton upload = new JButton("UPLOAD QUESTIONS");
	JButton logout = new JButton("");
	
	public SelectStudent(Vector<String> n)
	{
		this.name = n;
		nameLst = new JList<String>(name);
	   // int list = nameLst.getSelectedIndex();
	   // System.out.println(list);
	 
		//String name =nameLst.getModel();
		
		back.add(nameLst);
		setBounds(0, 0, 600, 500);
		setLayout(null);
		//////
		back.setBounds(0, 0, 600, 500);
		ImageIcon bac = new ImageIcon("imgs/background.jpeg");
		back.setIcon(bac);
		add(back);
		select.setBounds(50, 30, 400, 30);
		select.setForeground(Color.BLUE);
		select.setFont(new Font("Algerian",0,20));
		back.add(select);
		Java.setBounds(30, 80, 100, 20);
		back.add(Java);
		CPlus.setBounds(150, 80, 100, 20);
		back.add(CPlus);
		C.setBounds(270, 80, 100, 20);
		back.add(C);
		
		JScrollPane scr = new JScrollPane(nameLst, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		scr.setBounds(30, 130, 400, 200);
		nameLst.setBorder(BorderFactory.createEtchedBorder());
		nameLst.setBackground(new Color(200, 250, 205));
		nameLst.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		back.add(scr);
		
		submit.setBounds(50, 360, 120, 30);
		ImageIcon up = new ImageIcon("imgs/thumbsup.jpeg");
     	submit.setIcon(up);
		submit.addActionListener(this);
		back.add(submit);
		
		upload.setBounds(190, 360, 200, 30);
		ImageIcon upld = new ImageIcon("imgs/upload.jpeg");
        upload.setIcon(upld);
		upload.addActionListener(this);
		back.add(upload);
		
		logout.setBounds(470, 360, 30, 30);
		ImageIcon lgout = new ImageIcon("imgs/logout.jpeg");
		logout.setToolTipText("Logout Button");
        logout.setIcon(lgout);
		logout.addActionListener(this);
		back.add(logout);
		
		
		
		
		
		///////
		int width=0;int height =0;
	
		if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
		{	width=640;height=460;}
		else
		{
		width=720;height=540;	
		}
		Dimension dim= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((dim.width-width)/2,(dim.height-height)/2);
		
		/////
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	

	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//String selected = nameLst.getSelectedItem().toString();
		//String selected = nameLst.getSelectedValuesList().toString();
		//System.out.println(selected+"   @@@@@@@@@@@");
		Object [] n =  nameLst.getSelectedValues();
		
		
		//////////////
		//////////////
		/////////////
		if(e.getSource()==submit)
		{
			Connection con = CreateConnection.connect();
			
		    if(Java.isSelected())
		    {
		      try {
		    	  String JAVA ="java";
		    	  PreparedStatement pstmt = con.prepareStatement("update  login set field1=?,username=? where username=?"); 
		    	   pstmt.setString(1, JAVA);
		    	  for(int i=0;i<n.length;i++)
			    	{
		    		  pstmt.setString(2,(String)n[i]);
		    		  pstmt.setString(3,(String) n[i]);
		    		// System.out.println( (String)n[i]);
		    		  pstmt.executeUpdate();
		    	 }
		    	 pstmt.executeUpdate();
		    	  
		    	  JOptionPane.showMessageDialog(null, "Java Field is Selected");
		    	 pstmt.close();
		    	 
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}	
	 } 
		    else
		    {
		    	try{
		    	
		    		String JAVA =null;
		           PreparedStatement pstmt = con.prepareStatement("update  login set field1=?,username=? where username=?"); 
		    	   pstmt.setString(1, JAVA);
		    	  for(int i=0;i<n.length;i++)
			    	{
		    		  pstmt.setString(2,(String)n[i]);
		    		  pstmt.setString(3,(String) n[i]);
		    		// System.out.println( (String)n[i]);
		    		  pstmt.executeUpdate();
		    		  
		    		  //System.out.println("java null");
		    	 }
		    	 pstmt.executeUpdate();
		    	 JOptionPane.showMessageDialog(null, "Java filed is set as null");
		    	 pstmt.close();
		    	 
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    	
		    }
		    
		    if(CPlus.isSelected())
		    {
		    	try{
		    	String CPLUS ="C++";
		    	  PreparedStatement pstmt = con.prepareStatement("update  login set field2=?,username=? where username=?"); 
		    	   pstmt.setString(1, CPLUS);
		    	  for(int i=0;i<n.length;i++)
			    	{
		    		  pstmt.setString(2,(String)n[i]);
		    		  pstmt.setString(3,(String) n[i]);
		    		// System.out.println( (String)n[i]);
		    		  pstmt.executeUpdate();
		    	 }
		    	 pstmt.executeUpdate();
		    	  
		    	  JOptionPane.showMessageDialog(null, " C++ Field is Selected");
		    	 pstmt.close();
		    	 
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    }
		    else
		    {
		    	try{
		    	String CPLUS =null;
		    	  PreparedStatement pstmt = con.prepareStatement("update  login set field2=?,username=? where username=?"); 
		    	   pstmt.setString(1, CPLUS);
		    	  for(int i=0;i<n.length;i++)
			    	{
		    		  pstmt.setString(2,(String)n[i]);
		    		  pstmt.setString(3,(String) n[i]);
		    		// System.out.println( (String)n[i]);
		    		  pstmt.executeUpdate();
		    	 }
		    	 pstmt.executeUpdate();
		    	 JOptionPane.showMessageDialog(null, "C++ filed is set as null");
		    	 
		    	 pstmt.close();
		    	 
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    }
		    
		    if(C.isSelected())
		    {
		    	try{
			    	String C ="C";
			    	  PreparedStatement pstmt = con.prepareStatement("update  login set field3=?,username=? where username=?"); 
			    	   pstmt.setString(1, C);
			    	  for(int i=0;i<n.length;i++)
				    	{
			    		  pstmt.setString(2,(String)n[i]);
			    		  pstmt.setString(3,(String) n[i]);
			    		// System.out.println( (String)n[i]);
			    		  pstmt.executeUpdate();
			    	 }
			    	 pstmt.executeUpdate();
			    	  
			    	  JOptionPane.showMessageDialog(null, " C Field is Selected");
			    	 pstmt.close();
			    	 
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
		    }
		    
		    else{
		    	try{
			    	String C =null;
			    	  PreparedStatement pstmt = con.prepareStatement("update  login set field3=?,username=? where username=?"); 
			    	   pstmt.setString(1, C);
			    	 // for(int i=0;i<nameLst.getModel().getSize();i++)
			    	   for(int i=0;i<n.length;i++)
				    	{
			    		  pstmt.setString(2,(String) n[i]);
			    		  pstmt.setString(3,(String) n[i]);
			    		// System.out.println( (String)n[i]);
			    		  pstmt.executeUpdate();
			    	 }
			    	 pstmt.executeUpdate();
			    	 JOptionPane.showMessageDialog(null, "C filed is set as null");
			    	 
			    	 pstmt.close();
			    	 
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		    }
		   
		}
		
		/////////////
		/////////////
		/////////////
		
		if(e.getSource()==upload)
		{
			new Upload();
			this.dispose();
		}
		if(e.getSource()==logout)
		{
			JOptionPane.showMessageDialog(null, "You are going to Logout!");
			this.dispose();   
			JOptionPane.showMessageDialog(null, "You are Sucessfully logout..", "Sucess!!", JOptionPane.INFORMATION_MESSAGE);
	           	
		}
		
		
		
	}
	public static void main(String[] args) {
		
		Connection con = CreateConnection.connect();
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("Select username from login");
			
			 ResultSet rs1 = pstmt.executeQuery();
			 boolean flg = false;
			
			 Vector<String> v = new Vector<String>();
			while(rs1.next())
			{
			
			
			v.add(rs1.getString(1));
			flg = true;
			}
			
			if(flg==true)
			{
				
				new SelectStudent(v);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}




	

}