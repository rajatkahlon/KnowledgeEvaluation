import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.border.Border;


public class TestFrame extends JFrame {

	  String studentName = "";
		
		
		NorthWindow panelNorth = new NorthWindow(studentName);
		SouthWindow panelSouth = new SouthWindow();
		CenterWindow panelCenter = new CenterWindow(studentName);
		
		public TestFrame()
		{   
			getContentPane().setLayout(new BorderLayout());
			////
			
		    getContentPane().add(BorderLayout.NORTH,panelNorth);
		    getContentPane().add(BorderLayout.SOUTH,panelSouth);
		    getContentPane().add(BorderLayout.CENTER,panelCenter);
		    
		    int width=0;
		    int heigth=0;
		     if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
		     {width=640;heigth=460;}
		     else
		     {width=720;heigth=540;}
		     Dimension dim =java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		     setLocation((dim.width-width)/2, (dim.height-heigth)/2);
		     
		
			
		}
		
		
		public static void main(String[] args)
		{
			TestFrame frm =new TestFrame();
			frm.pack();
			frm.setTitle("Online Test");
			frm.setVisible(true);
			frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
	}
	class NorthWindow extends JPanel
	{ 
		String studentName=" ";
		String subject="";
		public NorthWindow(String studentName)
		{   
			this.studentName=studentName;
			setLayout(new GridLayout(2, 2));
			JLabel student,message;
			student=new JLabel("welcome: "+studentName+" to the online"+subject+"test");
			add(student);
			
			message = new JLabel(" ");
			add(message);
			new JLabel("        ");
			new JLabel("         ");
			setBackground(new Color(230,240,250));
			Border border = BorderFactory.createEtchedBorder();
			setBorder(border);
		}
	}
	class SouthWindow extends JPanel
	{
		JButton[] chooseButton = new JButton[4];
		public SouthWindow()
		{
		
			String[] key={"Start","Next","Previous","End"};
			for(int i=0;i<chooseButton.length;i++)
			{
				chooseButton[i]= new JButton(key[i]);
				add(chooseButton[i]);
			}
		    Border border = BorderFactory.createEtchedBorder();
		    setBorder(border);
			setBackground(new Color(230,240,250));
		}
	}
	class CenterWindow extends JPanel
	{
		public CenterWindow(String studentName)
		{
			Border border = BorderFactory.createEtchedBorder();
			setLayout(new GridLayout(1,2));
			JTextPane pane = new JTextPane();
			JScrollPane west = new JScrollPane(pane);
			pane.setForeground(Color.red);
			pane.setText("Java Online Test Week  \n \nINSTRUCTIONS:\nThere are 25 questions in this test and 30 minutes to complete them all.\nThe finish button is highlighted in blue when you reach the end of the test. \nClicking the finish button will display the results with the correct answers marked in light red.  \n \nThe timecounter  begins when you click on the 'start' button \n \nBest of luck!\n");

			pane.setEditable(false);
			pane.setBorder(border);
			add(pane);
			JPanel east = new JPanel();
			east.setLayout(new BorderLayout());
			east.setBorder(border);
			add(east);
			JPanel NorthEast = new JPanel();
			NorthEast.setBackground(new Color(255,150,240));
			east.add(BorderLayout.NORTH,NorthEast);
			JLabel ques =new JLabel("There are total 25 questions");
			NorthEast.add(ques);
			NorthEast.setBorder(border);
			
			JCheckBox[] box = new JCheckBox[4];
			JPanel EastWest = new JPanel();
			EastWest.setLayout(new GridLayout(6, 1));
			EastWest.add(new JLabel(" "));
			String[] boxes ={"A","B","C","D"};
			for(int i =0;i<box.length;i++)
			{
				box[i]= new JCheckBox(boxes[i]);
				EastWest.add(box[i]);
			}
			EastWest.add(new JLabel(" "));
			
			JTextArea[] Answer = new JTextArea[4];
			
			JLabel choose;
			JPanel CenterEast = new JPanel();
			east.add(BorderLayout.CENTER,CenterEast);
			CenterEast.setLayout(new GridLayout(6, 1));
			CenterEast.setBorder(border);
			
			choose=new JLabel("Chose Correct answer");
			choose.setBorder(border);
			choose.setBackground(new Color(230, 250, 255));
			CenterEast.add(choose);
			east.add(BorderLayout.WEST,EastWest);
			JScrollPane[] panes= new JScrollPane[4];
			for(int i =0;i<Answer.length;i++)
			{
				Answer[i] =new JTextArea();
				Answer[i].setBorder(border);
				Answer[i].setBackground(new Color(240,200,250));
				panes[i] = new JScrollPane(Answer[i]);
				CenterEast.add(Answer[i]);
				Answer[i].setLineWrap(true);
				Answer[i].setEditable(false);
				
			}
			JLabel time;
			time=new JLabel("You have only 30 minutes to complete");
			CenterEast.setBorder(border);
			CenterEast.add(time);
			
			
			
		}
	}
	
