import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Upload extends JFrame implements ActionListener{
	
	JLabel back = new JLabel();
	
	JRadioButton Java = new JRadioButton("JAVA");
	JRadioButton CPlus = new JRadioButton("C++");
	JRadioButton C = new JRadioButton("C");
	
	JLabel quesNo = new JLabel("Ques. No.");
	String[] nos ={"Select"};
	JComboBox comboNo = new JComboBox(nos);
	String[] newNos = new String[26];
	
	JLabel question = new JLabel("Question:");
	JTextArea quesArr = new JTextArea();
	JScrollPane quesScr = new JScrollPane(quesArr, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	
	JLabel options = new JLabel("Options:");
	JTextField optFld1 = new JTextField();
	JTextField optFld2 = new JTextField();
	JTextField optFld3 = new JTextField();
	JTextField optFld4 = new JTextField();
	
	JLabel answer = new JLabel("Answer:");
	String[] AnsStr ={"Select","1","2","3","4"};
	JComboBox Anscomb = new JComboBox(AnsStr);
	
	JButton Add = new JButton("");
	JButton Upload = new JButton("");
	JButton cancel = new JButton("");
	JButton Back = new JButton("");
	
	String Question,option1,option2,option3,option4,id,ans;
	public Upload()
	{
		setBounds(0, 0, 600, 500);
		setTitle("Upload Questions");
		setLayout(null);
		/////
		back.setBounds(0, 0, 600, 500);
		ImageIcon bac = new ImageIcon("imgs/background.jpeg");
		back.setIcon(bac);
		add(back);
		
		ButtonGroup bg = new ButtonGroup();
		Java.setBounds(30, 30, 100, 20);
		bg.add(Java);
		back.add(Java);
		CPlus.setBounds(150, 30, 100, 20);
		bg.add(CPlus);
		back.add(CPlus);
		C.setBounds(270, 30, 100, 20);
		bg.add(C);
		back.add(C);
		
		quesNo.setBounds(30, 70, 100, 30);
		back.add(quesNo);
		comboNo.setBounds(150,70,70,30);
		back.add(comboNo);
		for(int i=1;i<newNos.length;i++)
		{
			newNos[i]= new String(String.valueOf(i));
			comboNo.addItem(newNos[i]);
		}
		
		question.setBounds(30, 120, 100, 30);
		back.add(question);
		quesScr.setBounds(150, 120, 400, 100);
		quesArr.setLineWrap(true);
		back.add(quesScr);
		
		options.setBounds(30, 240, 200, 30);
		back.add(options);
		optFld1.setBounds(150, 240, 200, 30);
		back.add(optFld1);
		optFld2.setBounds(150, 275, 200, 30);
		back.add(optFld2);
		optFld3.setBounds(150, 310, 200, 30);
		back.add(optFld3);
		optFld4.setBounds(150, 345, 200, 30);
		back.add(optFld4);
		
		answer.setBounds(30, 400, 100, 30);
		back.add(answer);
		Anscomb.setBounds(150, 400, 70, 30);
		back.add(Anscomb);
		
		
		Upload.setBounds(350, 400, 30, 30);
		ImageIcon upld = new ImageIcon("imgs/upload.jpeg");
		Upload.setToolTipText("Upload the Questions");
        Upload.setIcon(upld);
		Upload.addActionListener(this);
		back.add(Upload);
		
		Add.setBounds(400, 400, 30, 30);
		ImageIcon add = new ImageIcon("imgs/add.jpeg");
		Add.setToolTipText("Add new Questions");
        Add.setIcon(add);
		Add.addActionListener(this);
		back.add(Add);
		
		Back.setBounds(450, 400, 30, 30);
		ImageIcon bk = new ImageIcon("imgs/back.jpeg");
		Back.setToolTipText("Back");
      	Back.setIcon(bk);
      	Back.addActionListener(this);
      	back.add(Back);
      	
      	cancel.setBounds(500, 400, 30, 30);
		ImageIcon down = new ImageIcon("imgs/exitdoor.png");
      	cancel.setIcon(down);
      	cancel.setToolTipText("Exit");
		cancel.addActionListener(this);
		back.add(cancel);
	
		
		////////
		int width=0;int height =0;
		if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
		{	width=640;height=460;}
		else
		{
		width=720;height=540;	
		}
		Dimension dim= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((dim.width-width)/2,(dim.height-height)/2);
		
		///////
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	

	
	@Override
	public void actionPerformed(ActionEvent e) {
		Connection con = CreateConnection.connect();
		if(e.getSource()==Add)
		{
			if(Java.isSelected())
			{
				if(quesArr.getText().equals("")&&optFld1.getText().equals("")&&optFld2.getText().equals("")&&optFld3.getText().equals("")&&optFld4.getText().equals("")&&comboNo.getSelectedItem().equals("Select")&&Anscomb.getSelectedItem().equals("Select"))
				{
					JOptionPane.showMessageDialog(null, "Please fill all the fields to ADD!");
				}
				else
				{
				
				
				Question = quesArr.getText();
				option1 = optFld1.getText();
				option2 = optFld2.getText();
				option3 = optFld3.getText();
				option4 = optFld4.getText();
				id =  (String) comboNo.getSelectedItem();
				ans = (String) Anscomb.getSelectedItem();
				
				try {
					
					
					PreparedStatement ps = con.prepareStatement("Select id from javaques");
					ResultSet rs = ps.executeQuery();
					boolean flag = true;
					while(rs.next())
					{
						if(id.equals(rs.getString(1)))
						{
							JOptionPane.showMessageDialog(null, "Question no. is already exits, please provide another no.");
							flag=false;
							break;
						}
					}
					
					if(flag==true){
					PreparedStatement pstmt = con.prepareStatement("insert into javaques (ques,option1,option2,option3,option4,answer,id) values(?,?,?,?,?,?,?)");
					
					pstmt.setString(1, Question);
					pstmt.setString(2, option1);
					pstmt.setString(3, option2);
					pstmt.setString(4, option3);
					pstmt.setString(5, option4);
					pstmt.setString(6, ans);
					pstmt.setString(7, id);
					
					pstmt.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "question added");
					
					quesArr.setText("");
					optFld1.setText("");
					optFld2.setText("");
					optFld3.setText("");
					optFld4.setText("");
					//comboNo.setSelectedItem("Select");
					Anscomb.setSelectedItem("Select");
					
					
					pstmt.close();
					
					
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
				
			}

           
			else if(CPlus.isSelected())
			{
				if(quesArr.getText().equals("")&&optFld1.getText().equals("")&&optFld2.getText().equals("")&&optFld3.getText().equals("")&&optFld4.getText().equals("")&&comboNo.getSelectedItem().equals("Select")&&Anscomb.getSelectedItem().equals("Select"))
				{
					JOptionPane.showMessageDialog(null, "Please fill all the fields to ADD!");
				}
				else
				{
				
				
				
				Question = quesArr.getText();
				option1 = optFld1.getText();
				option2 = optFld2.getText();
				option3 = optFld3.getText();
				option4 = optFld4.getText();
				id =  (String) comboNo.getSelectedItem();
				ans = (String) Anscomb.getSelectedItem();
				
				try {
					

					PreparedStatement ps = con.prepareStatement("Select id from cppques");
					ResultSet rs = ps.executeQuery();
					boolean flag = true;
					while(rs.next())
					{
						if(id.equals(rs.getString(1)))
						{
							JOptionPane.showMessageDialog(null, "Question no. is already exits, please provide another no.");
							flag=false;
							break;
						}
					}
					if(flag==true){
					PreparedStatement pstmt = con.prepareStatement("insert into cppques (ques,option1,option2,option3,option4,answer,id) values(?,?,?,?,?,?,?)");
					
					pstmt.setString(1, Question);
					pstmt.setString(2, option1);
					pstmt.setString(3, option2);
					pstmt.setString(4, option3);
					pstmt.setString(5, option4);
					pstmt.setString(6, ans);
					pstmt.setString(7, id);
					
					pstmt.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "question added");
					
					quesArr.setText("");
					optFld1.setText("");
					optFld2.setText("");
					optFld3.setText("");
					optFld4.setText("");
					//comboNo.setSelectedItem("Select");
					Anscomb.setSelectedItem("Select");
					
					pstmt.close();
					
					
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
				}
			}

			else if(C.isSelected())
			{
				if(quesArr.getText().equals("")&&optFld1.getText().equals("")&&optFld2.getText().equals("")&&optFld3.getText().equals("")&&optFld4.getText().equals("")&&comboNo.getSelectedItem().equals("Select")&&Anscomb.getSelectedItem().equals("Select"))
				{
					JOptionPane.showMessageDialog(null, "Please fill all the fields to ADD!");
				}
				else
				{
				
				
				
				Question = quesArr.getText();
				option1 = optFld1.getText();
				option2 = optFld2.getText();
				option3 = optFld3.getText();
				option4 = optFld4.getText();
				id =  (String) comboNo.getSelectedItem();
				ans = (String) Anscomb.getSelectedItem();
				
				try {
					

					PreparedStatement ps = con.prepareStatement("Select id from cques");
					ResultSet rs = ps.executeQuery();
					boolean flag = true;
					while(rs.next())
					{
						if(id.equals(rs.getString(1)))
						{
							JOptionPane.showMessageDialog(null, "Question no. is already exits, please provide another no.");
							flag=false;
							break;
						}
					}
					
					if(flag==true)
					{
					PreparedStatement pstmt = con.prepareStatement("insert into cques (ques,option1,option2,option3,option4,answer,id) values(?,?,?,?,?,?,?)");
					
					pstmt.setString(1, Question);
					pstmt.setString(2, option1);
					pstmt.setString(3, option2);
					pstmt.setString(4, option3);
					pstmt.setString(5, option4);
					pstmt.setString(6, ans);
					pstmt.setString(7, id);
					
					pstmt.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "question added");
					
					quesArr.setText("");
					optFld1.setText("");
					optFld2.setText("");
					optFld3.setText("");
					optFld4.setText("");
					//comboNo.setSelectedItem("Select");
					Anscomb.setSelectedItem("Select");
					
					pstmt.close();
					
					
				}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				}
			}

			else
			{
				JOptionPane.showMessageDialog(null, "Please select a Field..");
			}
		}
		if(e.getSource()==Upload)
		{
			if(Java.isSelected())
			{
				if(quesArr.getText().equals("")&&optFld1.getText().equals("")&&optFld2.getText().equals("")&&optFld3.getText().equals("")&&optFld4.getText().equals("")&&comboNo.getSelectedItem().equals("Select")&&Anscomb.getSelectedItem().equals("Select"))
				{
					JOptionPane.showMessageDialog(null, "Please fill all the fields to Upload!");
				}
				else
				{
				
				
				
				Question = quesArr.getText();
				option1 = optFld1.getText();
				option2 = optFld2.getText();
				option3 = optFld3.getText();
				option4 = optFld4.getText();
				id =  (String) comboNo.getSelectedItem();
				ans = (String) Anscomb.getSelectedItem();
				
				try {
					PreparedStatement pstmt = con.prepareStatement("update javaques set ques=?,option1=?,option2=?,option3=?,option4=?,answer=?  where id = ?");
					
					pstmt.setString(1, Question);
					pstmt.setString(2, option1);
					pstmt.setString(3, option2);
					pstmt.setString(4, option3);
					pstmt.setString(5, option4);
					pstmt.setString(6, ans);
					pstmt.setString(7, id);
					
					pstmt.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "question uploaded");
					
					quesArr.setText("");
					optFld1.setText("");
					optFld2.setText("");
					optFld3.setText("");
					optFld4.setText("");
					//comboNo.setSelectedItem("Select");
					Anscomb.setSelectedItem("Select");
					
					pstmt.close();
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
				
			}
			
			else if(CPlus.isSelected())
			{
				if(quesArr.getText().equals("")&&optFld1.getText().equals("")&&optFld2.getText().equals("")&&optFld3.getText().equals("")&&optFld4.getText().equals("")&&comboNo.getSelectedItem().equals("Select")&&Anscomb.getSelectedItem().equals("Select"))
				{
					JOptionPane.showMessageDialog(null, "Please fill all the fields to ADD!");
				}
				else
				{
				
				
				
				Question = quesArr.getText();
				option1 = optFld1.getText();
				option2 = optFld2.getText();
				option3 = optFld3.getText();
				option4 = optFld4.getText();
				id =  (String) comboNo.getSelectedItem();
				ans = (String) Anscomb.getSelectedItem();
				
				try {
					PreparedStatement pstmt = con.prepareStatement("update cppques set ques=?,option1=?,option2=?,option3=?,option4=?,answer=?  where id = ?");
					
					pstmt.setString(1, Question);
					pstmt.setString(2, option1);
					pstmt.setString(3, option2);
					pstmt.setString(4, option3);
					pstmt.setString(5, option4);
					pstmt.setString(6, ans);
					pstmt.setString(7, id);
					
					pstmt.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "question uploaded");
					quesArr.setText("");
					optFld1.setText("");
					optFld2.setText("");
					optFld3.setText("");
					optFld4.setText("");
					//comboNo.setSelectedItem("Select");
					Anscomb.setSelectedItem("Select");
					
					pstmt.close();
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				}
			}
			
			else if(C.isSelected())
			{
				if(quesArr.getText().equals("")&&optFld1.getText().equals("")&&optFld2.getText().equals("")&&optFld3.getText().equals("")&&optFld4.getText().equals("")&&comboNo.getSelectedItem().equals("Select")&&Anscomb.getSelectedItem().equals("Select"))
				{
					JOptionPane.showMessageDialog(null, "Please fill all the fields to ADD!");
				}
				else
				{
				
				
				
				Question = quesArr.getText();
				option1 = optFld1.getText();
				option2 = optFld2.getText();
				option3 = optFld3.getText();
				option4 = optFld4.getText();
				id =  (String) comboNo.getSelectedItem();
				ans = (String) Anscomb.getSelectedItem();
				
				try {
					PreparedStatement pstmt = con.prepareStatement("update cques set ques=?,option1=?,option2=?,option3=?,option4=?,answer=?  where id = ?");
					
					pstmt.setString(1, Question);
					pstmt.setString(2, option1);
					pstmt.setString(3, option2);
					pstmt.setString(4, option3);
					pstmt.setString(5, option4);
					pstmt.setString(6, ans);
					pstmt.setString(7, id);
					
					pstmt.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "question uploaded");
					quesArr.setText("");
					optFld1.setText("");
					optFld2.setText("");
					optFld3.setText("");
					optFld4.setText("");
					//comboNo.setSelectedItem("Select");
					Anscomb.setSelectedItem("Select");
					
					pstmt.close();
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				}
			}
			else{
				JOptionPane.showMessageDialog(null, "Please select a Field..");
			}
			
		}
		
		if(e.getSource()==Back)
		{
			//Connection con = CreateConnection.connect();
			PreparedStatement pstmt;
			try {
				pstmt = con.prepareStatement("Select username from login");
				
				 ResultSet rs1 = pstmt.executeQuery();
				 boolean flg = false;
				
				 Vector<String> v = new Vector<String>();
				while(rs1.next())
				{
				
				
				v.add(rs1.getString(1));
				flg = true;
				}
				
				if(flg==true)
				{
					
					new SelectStudent(v);
				}
				
				
			} catch (SQLException Ee) {
				// TODO Auto-generated catch block
				Ee.printStackTrace();
			}
			
			

			this.dispose();
		}
		
		if(e.getSource()==cancel)
		{
			this.dispose();
		}
	}
	
	public static void main(String[] args) {
		new Upload();

	}



}
