import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Welcome extends JFrame{
	
	JLabel back = new JLabel("");
	JLabel welcome = new JLabel("");
	JButton click = new JButton("");
	JLabel icon = new JLabel("");
	
	public Welcome()
	{   setBounds(0, 0, 600, 500);
		setLayout(null);
		setTitle("welcome");
		
		back.setBounds(0, 0, 600, 500);
		add(back);
		ImageIcon bac = new ImageIcon("imgs/background.jpeg");
		back.setIcon(bac);
		welcome.setBounds(100, 50, 400, 300);
		ImageIcon wel = new ImageIcon("imgs/welcome.jpeg");
		welcome.setIcon(wel);
		welcome.setHorizontalAlignment(welcome.CENTER);
		back.add(welcome);
		
		click.setBounds(200,350,150, 30);
		click.setText("Click here for Login");
		
		back.add(click);
		click.addActionListener(new ActionListener() {
				@Override
			public void actionPerformed(ActionEvent e) {
				new Login();
				dispose();
				
			}
		});
		icon.setBounds(350, 350, 30, 30);
		ImageIcon login = new ImageIcon("imgs/clickHereForLogin.png");
		icon.setIcon(login);
		back.add(icon);
		
		int width=0;int height =0;
		if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
		{	width=640;height=460;}
		else
		{
		width=720;height=540;	
		}
		Dimension dim= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((dim.width-width)/2,(dim.height-height)/2);
		
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	}
	public static void main(String[] args) {
		Welcome wel = new Welcome();
	}

}
