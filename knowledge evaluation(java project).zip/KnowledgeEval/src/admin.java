import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;


public class admin extends JFrame implements ActionListener {
	
	JLabel back = new JLabel(" ");
	JLabel log = new JLabel(" ");
	JLabel admin = new JLabel("");
	JLabel pwsd = new JLabel("Password :");
	JPasswordField pfld = new JPasswordField();
	JButton submit = new JButton("SUBMIT");
	JButton Back = new JButton("");
	
	String password;
	
	public admin()
	{
		setBounds(0, 0, 600, 500);
		setTitle("Login for Admin");
		setLayout(null);
		///////////
		back.setBounds(0, 0, 600, 500);
		ImageIcon bac = new ImageIcon("imgs/background.jpeg");
		back.setIcon(bac);
		add(back);
		log.setBounds(150, 15, 270, 150);
		ImageIcon labl = new ImageIcon("imgs/adminKeyLogin.jpeg");
		log.setIcon(labl);
		back.add(log);
		
		admin.setBounds(30, 170, 150, 240);
		ImageIcon img = new ImageIcon("imgs/adminLogin.jpeg");
		admin.setIcon(img);
		back.add(admin);
		
		pwsd.setBounds(250, 200, 100, 30);
		pwsd.setForeground(new Color(140, 40, 255));
		back.add(pwsd);
        
		pfld.setBounds(250, 250, 200, 30);
		pfld.setHorizontalAlignment(pfld.CENTER);
		back.add(pfld);
		
		submit.setBounds(250, 320, 150, 30);
		ImageIcon up = new ImageIcon("imgs/thumbsup.jpeg");
      	submit.setIcon(up);
      	submit.addActionListener(this);
		back.add(submit);
		
		Back.setBounds(420, 320, 30, 30);
		ImageIcon bk = new ImageIcon("imgs/back.jpeg");
		Back.setToolTipText("Back");
		Back.setIcon(bk);
		Back.addActionListener(this);
		back.add(Back);
		
		/////////////
		int width=0;int height =0;
		if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
		{	width=640;height=460;}
		else
		{
		width=720;height=540;	
		}
		Dimension dim= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((dim.width-width)/2,(dim.height-height)/2);
		//////////////
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==Back)
		{
			new Login();
			this.dispose();
		}
		if(e.getSource()==submit)
		{
			if(!pfld.getText().equals(""))
			{
				Connection con = CreateConnection.connect();
				password = pfld.getText();
				try {
					PreparedStatement ps = con.prepareStatement("Select password from admin where username='admin'");
					ResultSet rs = ps.executeQuery();
					rs.next();
					if(password.equals(rs.getObject(1)))
					{
						JOptionPane.showMessageDialog(null, "Login Successful");
						new adminRights();
						this.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Please enters the admin's Password");
						pfld.setText("");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Please enter the Password");
					
			}
				
		}
		
	}

	
	public static void main(String[] args) {
		new admin();

	}


	
}
