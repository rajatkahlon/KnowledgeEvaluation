import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.xml.stream.FactoryConfigurationError;





public class adminRights extends JFrame implements ActionListener{

	JLabel back = new JLabel(" ");
	JRadioButton faculty = new JRadioButton("FACULTY");
	JRadioButton student = new JRadioButton("STUDENT");
	JRadioButton questions = new JRadioButton("QUESTIONS");
	JLabel frameInfo = new JLabel();
	JPanel adminInfo = new JPanel();
	ButtonGroup bg = new ButtonGroup();
	JPanel facultyPanel = new JPanel();
	JPanel studentPanel = new JPanel();
	
	JTextPane admin = new JTextPane();
	///////////
	//FACULTY
	///////////
	JLabel username1 = new JLabel("UserName:");
	JTextField fldName1 = new JTextField();
	JButton submit1 = new JButton("Submit");
	JLabel pwsd1 = new JLabel("Password:");
	JTextField fldPwd1 = new JTextField();
	JLabel name1 = new JLabel("Name:");
	JTextField nameTxt1 = new JTextField();
	JLabel add1 = new JLabel("Address:");
	JTextArea addAra1 = new JTextArea();
	JLabel dob1 = new JLabel("DOB:");
	JTextField dobTxt1 = new JTextField();
	JLabel qual1 = new JLabel("Qualification:");
	JTextField qualTxt1 = new JTextField();
	JLabel desig1 = new JLabel("Designation:");
	JTextField desigTxt1 = new JTextField();
	JLabel contact1 = new JLabel("Contact:");
	JTextField contactTxt1 = new JTextField();
	JLabel email1 = new JLabel("Email ID:");
	JTextField emailTxt1 = new JTextField();
	JButton remove1 = new JButton("Remove");
	JButton Exit1 = new JButton("Exit");
	JButton clear1 = new JButton("Clear");
	String UserName1;
	
	////////////
	//STUDENT
	///////////
	JLabel username2 = new JLabel("UserName:");
	JTextField fldName2 = new JTextField();
	JButton submit2 = new JButton("Submit");
	JLabel pwsd2 = new JLabel("Password:");
	JTextField fldPwd2 = new JTextField();
	JLabel name2 = new JLabel("Name:");
	JTextField nameTxt2 = new JTextField();
	JLabel add2= new JLabel("Address:");
	JTextArea addAra2 = new JTextArea();
	JLabel dob2 = new JLabel("DOB:");
	JTextField dobTxt2 = new JTextField();
	JLabel qual2 = new JLabel("Qualification");
	JTextField qualTxt2 = new JTextField();
	JLabel contact2 = new JLabel("Contact");
	JTextField contactTxt2 = new JTextField();
	JLabel email2 = new JLabel("Email ID");
	JTextField emailTxt2 = new JTextField();
	
	JLabel Java = new JLabel("JAVA Result");
	JTextField JavaTxt = new JTextField();
	JLabel cpp = new JLabel("C++ Result");
	JTextField cppTxt = new JTextField();
	JLabel C = new JLabel("C Result");
	JTextField cText = new JTextField();
	
	JButton remove2 = new JButton("Remove");
	JButton Exit2 = new JButton("Exit");
	JButton clear2 = new JButton("Clear");
	String UserName2;
	//////////
	//CONSTRUCTOR
	//////////
	 Connection con;
	public adminRights()
	{
		
		setBounds(300, 30, 600, 700);
		setTitle("Access to Members");
		setLayout(null);
		////////
		back.setBounds(0, 0, 600, 700);
		ImageIcon bac = new ImageIcon("imgs/backgroundLong.jpg");
		back.setIcon(bac);
		add(back);
	    
		frameInfo.setBounds(50, 15, 500, 40);
		//frameInfo.setOpaque(true);
		frameInfo.setForeground(Color.BLUE);
		frameInfo.setFont(new Font("algerian", Font.ITALIC, 40));
		back.add(frameInfo);
		
		faculty.setBounds(100, 75, 100, 30);
		bg.add(faculty);
		faculty.addActionListener(this);
		back.add(faculty);
		
		student.setBounds(250, 75, 100, 30);
		bg.add(student);
		student.addActionListener(this);
		back.add(student);
		
		questions.setBounds(400, 75, 100, 30);
		bg.add(questions);
		questions.addActionListener(this);
		back.add(questions);
		
		
		
		adminInfo.setBounds(50,150,500,500);
		adminInfo.setBackground(new Color(240, 140, 255));
		adminInfo.setLayout(null);
		admin.setBounds(50, 50, 400, 400);
		admin.setBackground(new Color(240, 140, 255));
		admin.setText("Here you can find the information about the faculty and the student members of this application."+"\n"+"By clicking " +
				"on the above buttons you can find all the necessary Information about the particular student and teacher respectively."+"\n"+
				"As an administrator you will also has the right to remove the infomation of the recpective faculty and student from the database.");
		admin.setFont(new Font("times new roman",0,25));
		admin.setForeground(Color.RED);
		admin.setEditable(false);
		adminInfo.add(admin);
		frameInfo.setText("Welcome Administrator");
		back.add(adminInfo);
		//////////
		//////////
		facultyPanel.setBounds(50, 150, 500, 500);
		facultyPanel.setBackground(new Color(240, 140, 255));
		facultyPanel.setLayout(null);
		
		username1.setBounds(20, 30, 80, 30);
		facultyPanel.add(username1);
		fldName1.setBounds(125, 30, 100, 30);
		facultyPanel.add(fldName1);
		submit1.setBounds(250, 30, 100, 30);
		/************/
		//FACULTY
		/************/
		submit1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				UserName1 = fldName1.getText();
		        con = CreateConnection.connect();
		        if(!UserName1.equals("")){
		       try {
				PreparedStatement  pstmt1 = con.prepareStatement("Select * from loginfaculty where username = ? ");
				pstmt1.setString(1,UserName1);
				
				//System.out.println(username1.getText());
				ResultSet rs1 = pstmt1.executeQuery();
				if(rs1.next())
				{
				fldPwd1.setText(rs1.getString(11));
				nameTxt1.setText(rs1.getString(1)+" "+rs1.getString(2)+" "+rs1.getString(3));
				qualTxt1.setText(rs1.getString(4));
				desigTxt1.setText(rs1.getString(5));
				addAra1.setText(rs1.getString(6));
				dobTxt1.setText(rs1.getString(7));
				contactTxt1.setText(rs1.getString(8));
				emailTxt1.setText(rs1.getString(9));
				
				
				}
				else
				{
					JOptionPane.showMessageDialog(null, "No Record Exist for "+UserName1+ " UserName");
					fldName1.setText("");
				}
				pstmt1.close();
				rs1.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		        }
		        else
		        {
		        	JOptionPane.showMessageDialog(null, "Please Enter a User Name");
		        }
			}
		});
		facultyPanel.add(submit1);
		/************/
		pwsd1.setBounds(20, 70, 100, 30);
		facultyPanel.add(pwsd1);
	    fldPwd1.setBounds(125, 70, 100, 30);
	    fldPwd1.setEditable(false);
	    facultyPanel.add(fldPwd1);
		name1.setBounds(20, 110, 100, 30);
		facultyPanel.add(name1);
		nameTxt1.setBounds(125, 110, 100, 30);
		nameTxt1.setEditable(false);
		facultyPanel.add(nameTxt1);
		dob1.setBounds(20, 150, 100, 30);
		facultyPanel.add(dob1);
		dobTxt1.setBounds(125, 150, 100, 30);
		dobTxt1.setEditable(false);
		facultyPanel.add(dobTxt1);
		add1.setBounds(20, 190, 100, 30);
		facultyPanel.add(add1);
		addAra1.setBounds(125, 190, 300, 100);
		addAra1.setEditable(false);
		addAra1.setBackground(new Color(225, 230, 230));
		addAra1.setBorder(BorderFactory.createEtchedBorder());
		facultyPanel.add(addAra1);
		qual1.setBounds(20, 300, 100, 30);
		facultyPanel.add(qual1);
		qualTxt1.setBounds(125, 300, 100,30	);
		qualTxt1.setEditable(false);
		facultyPanel.add(qualTxt1);
		desig1.setBounds(20, 340, 100, 30);
		facultyPanel.add(desig1);
		desigTxt1.setBounds(125, 340, 150, 30);
		desigTxt1.setEditable(false);
		facultyPanel.add(desigTxt1);
		contact1.setBounds(20, 380, 100, 30);
		facultyPanel.add(contact1);
		contactTxt1.setBounds(125, 380, 150, 30);
		contactTxt1.setEditable(false);
		facultyPanel.add(contactTxt1);
		email1.setBounds(20, 420, 100, 30);
		facultyPanel.add(email1);
		emailTxt1.setBounds(125, 420, 150, 30);
		emailTxt1.setEditable(false);
		facultyPanel.add(emailTxt1);
		/************/
		/************/
		remove1.setBounds(50, 460, 100, 30);
		remove1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				UserName1 = fldName1.getText();
				if(!UserName1.equals("")){
				try {
					PreparedStatement pstmt = con.prepareStatement("Delete from loginfaculty where username = ?");
					pstmt.setString(1, UserName1);
				   
					pstmt.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data is sucessfully Removed");
					fldName1.setText("");
					fldPwd1.setText("");
					nameTxt1.setText("");
					qualTxt1.setText("");
					addAra1.setText("");
					dobTxt1.setText("");
					contactTxt1.setText("");
					emailTxt1.setText("");
					desigTxt1.setText("");
					pstmt.close();
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Please Submit a UserName");
				}
			}
		});
		facultyPanel.add(remove1);
		/************/
		/************/
		Exit1.setBounds(200, 460, 100, 30);
		Exit1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "You are going to Exit");
				dispose();
			}
		});
		facultyPanel.add(Exit1);
		/************/
		/************/
		clear1.setBounds(350, 460, 100, 30);
		clear1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				fldName1.setText("");
				fldPwd1.setText("");
				nameTxt1.setText("");
				qualTxt1.setText("");
				addAra1.setText("");
				dobTxt1.setText("");
				contactTxt1.setText("");
				emailTxt1.setText("");
				desigTxt1.setText("");
			}
		});
		facultyPanel.add(clear1);
		/************/
		/************/
		back.add(facultyPanel);
		facultyPanel.setVisible(false);
         ///////////
		///////////
		studentPanel.setBounds(50, 150, 500, 500);
		studentPanel.setBackground(new Color(240, 140, 255));
        studentPanel.setLayout(null);
        
        username2.setBounds(20, 30, 80, 30);
		studentPanel.add(username2);
		fldName2.setBounds(125, 30, 100, 30);
		studentPanel.add(fldName2);
		submit2.setBounds(250, 30, 100, 30);
		/************/
		/************/
		submit2.addActionListener(new ActionListener() 
		{
			@Override
			public void actionPerformed(ActionEvent e) {
	    UserName2 = fldName2.getText();
        con = CreateConnection.connect();
        if(!UserName2.equals("")){
       try {
		PreparedStatement  pstmt2 = con.prepareStatement("Select * from login where username = ? ");
		pstmt2.setString(1,UserName2);
		
		//System.out.println(username1.getText());
		ResultSet rs2 = pstmt2.executeQuery();
		if(rs2.next())
		{
		fldPwd2.setText(rs2.getString(10));
		nameTxt2.setText(rs2.getString(1)+" "+rs2.getString(2)+" "+rs2.getString(3));
		qualTxt2.setText(rs2.getString(4));
		addAra2.setText(rs2.getString(5));
		dobTxt2.setText(rs2.getString(6));
		contactTxt2.setText(rs2.getString(7));
		emailTxt2.setText(rs2.getString(8));
		if(rs2.getString(14)!=null)
		{
		JavaTxt.setText(rs2.getString(14));
		}
		else
		{
			JavaTxt.setText("NULL");
		}
		if(rs2.getString(15)!=null){
		cppTxt.setText(rs2.getString(15));
		}
		else
		{
			cppTxt.setText("NULL");
		}
		if(rs2.getString(16)!=null)
		{
		cText.setText(rs2.getString(16));
		}
		else
		{
			cText.setText("NULL");
		}
		
		}
		else
		{
			JOptionPane.showMessageDialog(null, "No Record Exist for "+UserName2+" UserName");
			fldName2.setText("");
		}
		pstmt2.close();
		rs2.close();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
			
        }	
        else
        	{
        	JOptionPane.showMessageDialog(null, "Please enter a User Name");
        	}
        	}
	
});
		/************/
		/************/
		studentPanel.add(submit2);
		
		pwsd2.setBounds(20, 70, 100, 30);
		studentPanel.add(pwsd2);
	    fldPwd2.setBounds(125, 70, 100, 30);
	    fldPwd2.setEditable(false);
	    studentPanel.add(fldPwd2);
	    name2.setBounds(20, 110, 100, 30);
		studentPanel.add(name2);
		nameTxt2.setBounds(125, 110, 100, 30);
		nameTxt2.setEditable(false);
		studentPanel.add(nameTxt2);
		dob2.setBounds(20, 150, 100, 30);
		studentPanel.add(dob2);
		dobTxt2.setBounds(125, 150, 100, 30);
		dobTxt2.setEditable(false);
		studentPanel.add(dobTxt2);
		add2.setBounds(20, 190, 100, 30);
		studentPanel.add(add2);
		addAra2.setBounds(125, 190, 300, 100);
		addAra2.setBackground(new Color(225, 230, 230));
		addAra2.setBorder(BorderFactory.createEtchedBorder());
		addAra2.setEditable(false);
		studentPanel.add(addAra2);
		qual2.setBounds(20, 300, 100, 30);
		studentPanel.add(qual2);
		qualTxt2.setBounds(125, 300, 100,30	);
		qualTxt2.setEditable(false);
		studentPanel.add(qualTxt2);
		contact2.setBounds(20, 340, 100, 30);
		studentPanel.add(contact2);
		contactTxt2.setBounds(125, 340, 150, 30);
		contactTxt2.setEditable(false);
		studentPanel.add(contactTxt2);
		email2.setBounds(20, 380, 100, 30);
		studentPanel.add(email2);
		emailTxt2.setBounds(125, 380, 150, 30);
		emailTxt2.setEditable(false);
		studentPanel.add(emailTxt2);
		Java.setBounds(20, 420, 80, 30);
		studentPanel.add(Java);
		JavaTxt.setBounds(105, 420, 40, 30);
		JavaTxt.setEditable(false);
		studentPanel.add(JavaTxt);
		cpp.setBounds(155, 420, 80, 30);
		studentPanel.add(cpp);
		cppTxt.setBounds(240, 420, 40, 30);
		cppTxt.setEditable(false);
		studentPanel.add(cppTxt);
		C.setBounds(290, 420, 80, 30);
		studentPanel.add(C);
		cText.setBounds(380, 420, 40, 30);
		cText.setEditable(false);
		studentPanel.add(cText);
		/************/
		/************/
		remove2.setBounds(50, 460, 100, 30);
		remove2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		     UserName2 = fldName2.getText();
		     if(!UserName2.equals("")){
		     try {
					PreparedStatement pstmt = con.prepareStatement("Delete from login where username = ?");
					pstmt.setString(1, UserName2);
				   
					pstmt.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data is sucessfully Removed");
					fldName2.setText("");
					fldPwd2.setText("");
					nameTxt2.setText("");
					qualTxt2.setText("");
					addAra2.setText("");
					dobTxt2.setText("");
					contactTxt2.setText("");
					emailTxt2.setText("");
					JavaTxt.setText("");
					cppTxt.setText("");
					cText.setText("");
					pstmt.close();
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
		     }
		     else
		     {
		    	 JOptionPane.showMessageDialog(null, "Please Submit a UserName");
		     }
				
			}
		});
		studentPanel.add(remove2);
		/************/
		/************/
		Exit2.setBounds(200, 460, 100, 30);
		Exit2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "You are going to Exit");
				dispose();
				
			}
		});
        studentPanel.add(Exit2);
        /************/
        /************/
        clear2.setBounds(350, 460, 100, 30);
        clear2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				fldName2.setText("");
				fldPwd2.setText("");
				nameTxt2.setText("");
				qualTxt2.setText("");
				addAra2.setText("");
				dobTxt2.setText("");
				contactTxt2.setText("");
				emailTxt2.setText("");
				JavaTxt.setText("");
				cppTxt.setText("");
				cText.setText("");
				
			}
		});
		studentPanel.add(clear2);
		/************/
		/************/
		back.add(studentPanel);
		studentPanel.setVisible(false);
        ////////////
         /////////////
	    int width=0;int height =0;
	    if(java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()<799)
     	{	width=640;height=460;}
	    else
	    {
	    width=720;height=540;	
	    }
	    Dimension dim= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
	    //setLocation((dim.width-width)/2,(dim.height-height)/2);
	    //////////////
	    setVisible(true);
	    setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(faculty.isSelected())
		{
			
			studentPanel.setVisible(false);
			adminInfo.setVisible(false);
			facultyPanel.setVisible(true);
			frameInfo.setText("FACULTY INFORMATION");
		}
		if(student.isSelected())
		{
			adminInfo.setVisible(false);
			facultyPanel.setVisible(false);
			studentPanel.setVisible(true);
			frameInfo.setText("STUDENT INFORMATION");
		}
		if(questions.isSelected())
		{
			new AdminQuestions();
			this.setVisible(false);
		}
	}
	public static void main(String[] args) {
		new adminRights();
	}
	

}
